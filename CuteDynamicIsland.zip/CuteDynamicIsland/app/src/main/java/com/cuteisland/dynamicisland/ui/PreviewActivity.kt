package com.cuteisland.dynamicisland.ui

import android.os.Bundle
import android.view.View
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.EventFactory
import com.google.android.material.chip.ChipGroup

/** Try every event on a pretend phone screen without plugging anything in. */
class PreviewActivity : BaseActivity() {

    private lateinit var island: IslandView
    private var current = EventFactory.Sample.CHARGING

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview)
        setupToolbar(R.string.preview_title)

        island = findViewById(R.id.preview_island)
        setupPreview(island, EventFactory.sample(this, settings, current), loop = false)

        val labels = mapOf(
            EventFactory.Sample.CHARGING to R.string.event_charging,
            EventFactory.Sample.FULL to R.string.event_full,
            EventFactory.Sample.UNPLUGGED to R.string.event_unplugged,
            EventFactory.Sample.AIRPODS to R.string.event_airpods,
            EventFactory.Sample.DEVICE to R.string.event_device,
            EventFactory.Sample.DISCONNECTED to R.string.event_disconnected
        )
        bindChips(
            findViewById<ChipGroup>(R.id.chips_event), EventFactory.Sample.entries,
            { getString(labels.getValue(it)) }, current
        ) {
            current = it
            play()
        }

        findViewById<View>(R.id.btn_replay).setOnClickListener { play() }
        findViewById<View>(R.id.btn_play_on_screen).setOnClickListener {
            playOnScreen(EventFactory.sample(this, settings, current), island)
        }
    }

    override fun onResume() {
        super.onResume()
        island.post { play() }
    }

    private fun play() {
        island.look = settings.look()
        island.event = EventFactory.sample(this, settings, current)
        island.play()
    }
}
