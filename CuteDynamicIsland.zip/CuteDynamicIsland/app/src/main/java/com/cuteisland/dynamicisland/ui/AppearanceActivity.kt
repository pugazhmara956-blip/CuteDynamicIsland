package com.cuteisland.dynamicisland.ui

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.annotation.StringRes
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.EventFactory
import com.cuteisland.dynamicisland.model.IslandAlignment
import com.google.android.material.button.MaterialButtonToggleGroup
import kotlin.math.roundToInt

/** Width, height, corner radius, position, color, speed and display time. */
class AppearanceActivity : BaseActivity() {

    private lateinit var island: IslandView
    private lateinit var colorContainer: LinearLayout

    private data class Swatch(val color: Int, @StringRes val name: Int)

    private val swatches = listOf(
        Swatch(0xFF000000.toInt(), R.string.color_black),
        Swatch(0xFF0F172A.toInt(), R.string.color_midnight),
        Swatch(0xFF2E1065.toInt(), R.string.color_purple),
        Swatch(0xFF27272A.toInt(), R.string.color_graphite),
        Swatch(0xFF0C4A6E.toInt(), R.string.color_ocean),
        Swatch(0xFF881337.toInt(), R.string.color_rose),
        Swatch(0xFF14532D.toInt(), R.string.color_forest)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appearance)
        setupToolbar(R.string.appearance_title)

        island = findViewById(R.id.appearance_island)
        island.holdOpen = true
        setupPreview(island, EventFactory.sample(this, settings, EventFactory.Sample.CHARGING), loop = false)

        findViewById<MaterialButtonToggleGroup>(R.id.toggle_preview_mode)
            .addOnButtonCheckedListener { _, checkedId, isChecked ->
                if (!isChecked) return@addOnButtonCheckedListener
                island.holdCollapsed = checkedId == R.id.btn_mode_pill
                island.play()
            }

        val shape = findViewById<LinearLayout>(R.id.shape_container)
        addSliderRow(shape, R.string.width, 80f, 240f, 2f, settings.widthDp.toFloat(), this::dp) {
            settings.widthDp = it.roundToInt(); updateLook()
        }
        addSliderRow(shape, R.string.height, 24f, 56f, 1f, settings.heightDp.toFloat(), this::dp) {
            settings.heightDp = it.roundToInt(); updateLook()
        }
        addSliderRow(shape, R.string.corner_radius, 0f, 28f, 1f, settings.radiusDp.toFloat(), this::dp) {
            settings.radiusDp = it.roundToInt(); updateLook()
        }

        val position = findViewById<LinearLayout>(R.id.position_container)
        addSliderRow(position, R.string.distance_from_top, 0f, 300f, 1f, settings.offsetYDp.toFloat(), this::dp) {
            settings.offsetYDp = it.roundToInt()
        }

        val alignGroup = findViewById<MaterialButtonToggleGroup>(R.id.toggle_alignment)
        alignGroup.check(
            when (settings.alignment) {
                IslandAlignment.LEFT -> R.id.btn_align_left
                IslandAlignment.CENTER -> R.id.btn_align_center
                IslandAlignment.RIGHT -> R.id.btn_align_right
            }
        )
        alignGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            settings.alignment = when (checkedId) {
                R.id.btn_align_left -> IslandAlignment.LEFT
                R.id.btn_align_right -> IslandAlignment.RIGHT
                else -> IslandAlignment.CENTER
            }
            updateLook()
        }

        val motion = findViewById<LinearLayout>(R.id.motion_container)
        addSliderRow(
            motion, R.string.animation_speed, 50f, 200f, 10f, settings.speed * 100f,
            { getString(R.string.value_speed, it / 100f) }
        ) {
            settings.speed = it / 100f; updateLook()
        }
        addSliderRow(
            motion, R.string.display_time, 2f, 10f, 1f, settings.durationSec.toFloat(),
            { getString(R.string.value_seconds, it.roundToInt()) }
        ) {
            settings.durationSec = it.roundToInt()
        }

        colorContainer = findViewById(R.id.color_container)
        buildSwatches()

        findViewById<View>(R.id.btn_show_on_screen).setOnClickListener {
            playOnScreen(EventFactory.sample(this, settings, EventFactory.Sample.CHARGING), null)
        }
        findViewById<View>(R.id.btn_reset).setOnClickListener {
            settings.resetAppearance()
            Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show()
            recreate()
        }
    }

    private fun dp(value: Float): String = getString(R.string.value_dp, value.roundToInt())

    private fun updateLook() {
        island.look = settings.look()
    }

    private fun buildSwatches() {
        colorContainer.removeAllViews()
        val density = resources.displayMetrics.density
        val sizePx = (44 * density).toInt()
        val current = settings.color
        swatches.forEach { swatch ->
            val selected = swatch.color == current
            val view = View(this)
            val params = LinearLayout.LayoutParams(sizePx, sizePx)
            params.marginEnd = (12 * density).toInt()
            view.layoutParams = params
            view.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(swatch.color)
                setStroke(
                    ((if (selected) 3 else 1) * density).toInt(),
                    getColor(if (selected) R.color.accent_pink else R.color.card_stroke)
                )
            }
            val name = getString(swatch.name)
            view.contentDescription = if (selected) getString(R.string.color_selected, name) else name
            view.isClickable = true
            view.isFocusable = true
            view.setOnClickListener {
                settings.color = swatch.color
                buildSwatches()
                updateLook()
            }
            colorContainer.addView(view)
        }
    }
}
