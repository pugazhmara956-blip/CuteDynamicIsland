package com.cuteisland.dynamicisland.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.island.CharacterView
import com.cuteisland.dynamicisland.model.CharacterType
import com.google.android.material.snackbar.Snackbar

/** The free character collection. */
class CharactersActivity : BaseActivity() {

    private class Row(val type: CharacterType, val inUse: TextView)

    private val rows = ArrayList<Row>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_characters)
        setupToolbar(R.string.nav_characters)
        findViewById<TextView>(R.id.intro_text).setText(R.string.characters_intro)
        val container = findViewById<LinearLayout>(R.id.container)

        CharacterType.entries.forEach { type ->
            val card = layoutInflater.inflate(R.layout.item_character, container, false)
            card.findViewById<CharacterView>(R.id.char_view).character = type
            card.findViewById<TextView>(R.id.char_name).setText(type.nameRes)
            card.findViewById<TextView>(R.id.char_desc).setText(type.descRes)
            val inUse = card.findViewById<TextView>(R.id.char_in_use)
            card.findViewById<View>(R.id.btn_char_charging).setOnClickListener {
                settings.chargingCharacter = type
                refreshInUse()
                confirm()
            }
            card.findViewById<View>(R.id.btn_char_bluetooth).setOnClickListener {
                settings.btCharacter = type
                refreshInUse()
                confirm()
            }
            rows.add(Row(type, inUse))
            container.addView(card)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshInUse()
    }

    private fun confirm() {
        Snackbar.make(findViewById(android.R.id.content), R.string.saved, Snackbar.LENGTH_SHORT).show()
    }

    private fun refreshInUse() {
        val charging = settings.chargingCharacter
        val bt = settings.btCharacter
        rows.forEach { row ->
            val text = when {
                row.type == charging && row.type == bt -> R.string.in_use_both
                row.type == charging -> R.string.in_use_charging
                row.type == bt -> R.string.in_use_bluetooth
                else -> R.string.in_use_none
            }
            row.inUse.setText(text)
            row.inUse.setTextColor(getColor(if (text == R.string.in_use_none) R.color.text_muted else R.color.accent_green))
        }
    }
}
