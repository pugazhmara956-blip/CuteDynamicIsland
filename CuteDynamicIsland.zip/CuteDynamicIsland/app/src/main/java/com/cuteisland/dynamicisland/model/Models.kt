package com.cuteisland.dynamicisland.model

import androidx.annotation.StringRes
import com.cuteisland.dynamicisland.R

/** The visual styles the island can use when it opens. */
enum class AnimationStyle(@StringRes val titleRes: Int, @StringRes val descRes: Int) {
    SMALL_PILL(R.string.style_small_pill, R.string.style_small_pill_desc),
    EXPANDING(R.string.style_expanding, R.string.style_expanding_desc),
    BOUNCING(R.string.style_bouncing, R.string.style_bouncing_desc),
    ELECTRIC(R.string.style_electric, R.string.style_electric_desc),
    GLOWING(R.string.style_glowing, R.string.style_glowing_desc),
    BLUETOOTH(R.string.style_bluetooth, R.string.style_bluetooth_desc),
    WALKING(R.string.style_walking, R.string.style_walking_desc);

    companion object {
        fun fromName(name: String?, fallback: AnimationStyle): AnimationStyle =
            entries.firstOrNull { it.name == name } ?: fallback
    }
}

/** All original characters. They are drawn in code, so no image files are needed. */
enum class CharacterType(@StringRes val nameRes: Int, @StringRes val descRes: Int) {
    CAT_AND_MOUSE(R.string.char_cat_mouse, R.string.char_cat_mouse_desc),
    KITTEN(R.string.char_kitten, R.string.char_kitten_desc),
    PUPPY(R.string.char_puppy, R.string.char_puppy_desc),
    PANDA(R.string.char_panda, R.string.char_panda_desc),
    TEDDY(R.string.char_teddy, R.string.char_teddy_desc),
    BUNNY(R.string.char_bunny, R.string.char_bunny_desc),
    ANIME_GIRL(R.string.char_anime, R.string.char_anime_desc),
    HEARTS(R.string.char_hearts, R.string.char_hearts_desc),
    BATTERY_BUDDY(R.string.char_battery, R.string.char_battery_desc),
    FUNNY_BLOB(R.string.char_blob, R.string.char_blob_desc),
    EARBUD_BUDDY(R.string.char_earbud, R.string.char_earbud_desc);

    companion object {
        fun fromName(name: String?, fallback: CharacterType): CharacterType =
            entries.firstOrNull { it.name == name } ?: fallback
    }
}

enum class IslandAlignment(@StringRes val labelRes: Int) {
    LEFT(R.string.align_left),
    CENTER(R.string.align_center),
    RIGHT(R.string.align_right);

    companion object {
        fun fromName(name: String?): IslandAlignment =
            entries.firstOrNull { it.name == name } ?: CENTER
    }
}

enum class EventKind { CHARGING, CHARGER_DISCONNECTED, FULLY_CHARGED, BT_CONNECTED, BT_DISCONNECTED }

enum class Mood { HAPPY, EXCITED, SAD }

/** Everything the island needs to know about its size, shape and motion. */
data class IslandLook(
    val widthDp: Int,
    val heightDp: Int,
    val radiusDp: Int,
    val color: Int,
    val speed: Float,
    val alignment: IslandAlignment,
    val offsetYDp: Int,
    val durationSec: Int
) {
    companion object {
        const val DEFAULT_WIDTH = 130
        const val DEFAULT_HEIGHT = 36
        const val DEFAULT_RADIUS = 18
        /** Opaque black (0xFF000000 written as a signed Int). */
        const val DEFAULT_COLOR = -0x1000000
        const val DEFAULT_SPEED = 1.0f
        const val DEFAULT_OFFSET = 8
        const val DEFAULT_DURATION = 4

        val DEFAULT = IslandLook(
            DEFAULT_WIDTH, DEFAULT_HEIGHT, DEFAULT_RADIUS, DEFAULT_COLOR,
            DEFAULT_SPEED, IslandAlignment.CENTER, DEFAULT_OFFSET, DEFAULT_DURATION
        )
    }
}

/** One thing the island should announce. */
data class IslandEvent(
    val kind: EventKind,
    val title: String,
    val subtitle: String,
    /** Battery percentage, or -1 when it is not known. */
    val percent: Int,
    val style: AnimationStyle,
    val character: CharacterType,
    val accent: Int,
    val mood: Mood,
    val deviceAddress: String? = null
) {
    val isCharging: Boolean get() = kind == EventKind.CHARGING || kind == EventKind.FULLY_CHARGED
    val isBluetooth: Boolean get() = kind == EventKind.BT_CONNECTED || kind == EventKind.BT_DISCONNECTED
}
