package com.cuteisland.dynamicisland.ui

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.EventFactory
import com.cuteisland.dynamicisland.service.IslandService
import com.cuteisland.dynamicisland.util.PermissionHelper
import com.google.android.material.materialswitch.MaterialSwitch

/** Home screen: live preview, on/off switch, quick tests and navigation. */
class MainActivity : BaseActivity() {

    private lateinit var island: IslandView
    private lateinit var masterSwitch: MaterialSwitch
    private lateinit var statusText: TextView
    private lateinit var statusIcon: ImageView
    private lateinit var setupCard: View
    private var updatingSwitch = false
    private var demoIndex = 0

    private val demoSamples = listOf(
        EventFactory.Sample.CHARGING,
        EventFactory.Sample.AIRPODS,
        EventFactory.Sample.FULL
    )

    private data class NavItem(
        @DrawableRes val icon: Int,
        val tint: Int,
        @StringRes val title: Int,
        @StringRes val desc: Int,
        val target: Class<*>
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        island = findViewById(R.id.home_island)
        masterSwitch = findViewById(R.id.switch_master)
        statusText = findViewById(R.id.status_text)
        statusIcon = findViewById(R.id.status_icon)
        setupCard = findViewById(R.id.card_setup)

        setupPreview(island, EventFactory.sample(this, settings, demoSamples[0]))
        island.onClosed = {
            demoIndex = (demoIndex + 1) % demoSamples.size
            island.event = EventFactory.sample(this, settings, demoSamples[demoIndex])
        }

        findViewById<View>(R.id.btn_test_charging).setOnClickListener {
            playOnScreen(EventFactory.sample(this, settings, EventFactory.Sample.CHARGING), island)
        }
        findViewById<View>(R.id.btn_test_full).setOnClickListener {
            playOnScreen(EventFactory.sample(this, settings, EventFactory.Sample.FULL), island)
        }
        findViewById<View>(R.id.btn_test_airpods).setOnClickListener {
            playOnScreen(EventFactory.sample(this, settings, EventFactory.Sample.AIRPODS), island)
        }
        findViewById<View>(R.id.btn_finish_setup).setOnClickListener { open(SetupActivity::class.java) }

        masterSwitch.setOnCheckedChangeListener { _, checked ->
            if (!updatingSwitch) onMasterChanged(checked)
        }

        buildNavigation()
    }

    override fun onResume() {
        super.onResume()
        island.look = settings.look()
        island.event = EventFactory.sample(this, settings, demoSamples[demoIndex])
        if (settings.masterEnabled && PermissionHelper.canDrawOverlays(this) && !IslandService.isRunning) {
            IslandService.start(this)
        }
        refreshStatus()
    }

    private fun onMasterChanged(checked: Boolean) {
        if (checked) {
            if (!PermissionHelper.canDrawOverlays(this)) {
                setSwitch(false)
                open(SetupActivity::class.java)
                return
            }
            settings.masterEnabled = true
            IslandService.start(this)
        } else {
            settings.masterEnabled = false
            IslandService.stop(this)
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        val canDraw = PermissionHelper.canDrawOverlays(this)
        val on = settings.masterEnabled && canDraw
        setSwitch(on)
        val (textRes, color) = when {
            !canDraw -> R.string.service_needs_permission to getColor(R.color.accent_amber)
            settings.masterEnabled -> R.string.service_running to getColor(R.color.accent_green)
            else -> R.string.service_stopped to getColor(R.color.text_muted)
        }
        statusText.setText(textRes)
        statusIcon.backgroundTintList = ColorStateList.valueOf(color)
        statusIcon.imageTintList = ColorStateList.valueOf(getColor(R.color.bg_dark))
        setupCard.visibility = if (canDraw) View.GONE else View.VISIBLE
    }

    private fun setSwitch(checked: Boolean) {
        updatingSwitch = true
        masterSwitch.isChecked = checked
        updatingSwitch = false
    }

    private fun buildNavigation() {
        val items = listOf(
            NavItem(R.drawable.ic_sparkle, getColor(R.color.accent_purple), R.string.nav_gallery, R.string.nav_gallery_desc, GalleryActivity::class.java),
            NavItem(R.drawable.ic_paw, getColor(R.color.accent_pink), R.string.nav_characters, R.string.nav_characters_desc, CharactersActivity::class.java),
            NavItem(R.drawable.ic_bolt, getColor(R.color.accent_green), R.string.nav_battery, R.string.nav_battery_desc, BatterySettingsActivity::class.java),
            NavItem(R.drawable.ic_bluetooth, getColor(R.color.accent_blue), R.string.nav_bluetooth, R.string.nav_bluetooth_desc, BluetoothSettingsActivity::class.java),
            NavItem(R.drawable.ic_palette, getColor(R.color.accent_amber), R.string.nav_appearance, R.string.nav_appearance_desc, AppearanceActivity::class.java),
            NavItem(R.drawable.ic_phone, getColor(R.color.accent_cyan), R.string.nav_preview, R.string.nav_preview_desc, PreviewActivity::class.java),
            NavItem(R.drawable.ic_shield, getColor(R.color.accent_red), R.string.nav_setup, R.string.nav_setup_desc, SetupActivity::class.java),
            NavItem(R.drawable.ic_info, getColor(R.color.text_secondary), R.string.nav_help, R.string.nav_help_desc, HelpActivity::class.java)
        )
        val container = findViewById<LinearLayout>(R.id.nav_container)
        items.forEach { item ->
            val card = layoutInflater.inflate(R.layout.item_nav_card, container, false)
            val icon = card.findViewById<ImageView>(R.id.nav_icon)
            icon.setImageResource(item.icon)
            icon.backgroundTintList = ColorStateList.valueOf(item.tint)
            icon.imageTintList = ColorStateList.valueOf(getColor(R.color.bg_dark))
            card.findViewById<TextView>(R.id.nav_title).setText(item.title)
            card.findViewById<TextView>(R.id.nav_desc).setText(item.desc)
            card.setOnClickListener { open(item.target) }
            container.addView(card)
        }
    }
}
