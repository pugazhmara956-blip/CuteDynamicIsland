package com.cuteisland.dynamicisland.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.AnimationStyle
import com.cuteisland.dynamicisland.model.CharacterType
import com.cuteisland.dynamicisland.model.EventFactory
import com.google.android.material.chip.ChipGroup

/** Charging, unplugged and fully charged animation settings. */
class BatterySettingsActivity : BaseActivity() {

    private lateinit var island: IslandView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_battery_settings)
        setupToolbar(R.string.battery_title)

        island = findViewById(R.id.battery_island)
        setupPreview(island, sample(EventFactory.Sample.CHARGING))

        val switches = findViewById<LinearLayout>(R.id.switch_container)
        addSwitchRow(switches, R.string.sw_charging, R.string.sw_charging_desc, settings.chargingEnabled) {
            settings.chargingEnabled = it
        }
        addSwitchRow(switches, R.string.sw_unplugged, R.string.sw_unplugged_desc, settings.unpluggedEnabled) {
            settings.unpluggedEnabled = it
        }
        addSwitchRow(switches, R.string.sw_full, R.string.sw_full_desc, settings.fullChargeEnabled) {
            settings.fullChargeEnabled = it
        }

        bindChips(
            findViewById<ChipGroup>(R.id.chips_style), AnimationStyle.entries,
            { getString(it.titleRes) }, settings.chargingStyle
        ) {
            settings.chargingStyle = it
            replayPreview()
        }
        bindChips(
            findViewById<ChipGroup>(R.id.chips_character), CharacterType.entries,
            { getString(it.nameRes) }, settings.chargingCharacter
        ) {
            settings.chargingCharacter = it
            replayPreview()
        }

        findViewById<View>(R.id.btn_test_charging).setOnClickListener {
            playOnScreen(sample(EventFactory.Sample.CHARGING), island)
        }
        findViewById<View>(R.id.btn_test_unplugged).setOnClickListener {
            playOnScreen(sample(EventFactory.Sample.UNPLUGGED), island)
        }
        findViewById<View>(R.id.btn_test_full).setOnClickListener {
            playOnScreen(sample(EventFactory.Sample.FULL), island)
        }
    }

    override fun onResume() {
        super.onResume()
        island.look = settings.look()
    }

    private fun sample(s: EventFactory.Sample) = EventFactory.sample(this, settings, s)

    private fun replayPreview() {
        island.look = settings.look()
        island.event = sample(EventFactory.Sample.CHARGING)
        island.play()
    }
}
