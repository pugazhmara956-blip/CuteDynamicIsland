package com.cuteisland.dynamicisland.ui

import android.content.Intent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.data.IslandSettings
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.IslandEvent
import com.cuteisland.dynamicisland.overlay.IslandOverlay
import com.cuteisland.dynamicisland.util.PermissionHelper
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import kotlin.math.roundToInt

/** Shared helpers for every screen. */
abstract class BaseActivity : AppCompatActivity() {

    protected val settings: IslandSettings by lazy { IslandSettings(this) }

    protected fun setupToolbar(@StringRes title: Int) {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setTitle(title)
        toolbar.setNavigationOnClickListener { finish() }
    }

    protected fun open(target: Class<*>) {
        startActivity(Intent(this, target))
    }

    /** Sets up an in-app preview island that replays by itself and on tap. */
    protected fun setupPreview(view: IslandView, event: IslandEvent, loop: Boolean = true) {
        view.look = settings.look()
        view.event = event
        view.demoLoop = loop
        view.setOnClickListener { view.play() }
    }

    /**
     * Plays the event over other apps. If Display over other apps is not allowed yet,
     * the event plays in the in-app preview and the user is offered the setup screen.
     */
    protected fun playOnScreen(event: IslandEvent, fallback: IslandView?) {
        if (PermissionHelper.canDrawOverlays(this) && IslandOverlay.show(this, event)) return
        fallback?.let {
            it.look = settings.look()
            it.event = event
            it.play()
        }
        Snackbar.make(findViewById(android.R.id.content), R.string.test_needs_overlay, Snackbar.LENGTH_LONG)
            .setAction(R.string.set_up) { open(SetupActivity::class.java) }
            .show()
    }

    protected fun addSwitchRow(
        container: LinearLayout, @StringRes title: Int, @StringRes desc: Int,
        checked: Boolean, onChange: (Boolean) -> Unit
    ): MaterialSwitch {
        val row = layoutInflater.inflate(R.layout.item_switch_row, container, false)
        row.findViewById<TextView>(R.id.row_title).setText(title)
        row.findViewById<TextView>(R.id.row_desc).setText(desc)
        val sw = row.findViewById<MaterialSwitch>(R.id.row_switch)
        sw.isChecked = checked
        sw.contentDescription = getString(title)
        sw.setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
        row.setOnClickListener { sw.toggle() }
        container.addView(row)
        return sw
    }

    protected fun addSliderRow(
        container: LinearLayout, @StringRes label: Int,
        from: Float, to: Float, step: Float, value: Float,
        format: (Float) -> String, onChange: (Float) -> Unit
    ): Slider {
        val row = layoutInflater.inflate(R.layout.item_slider_row, container, false)
        row.findViewById<TextView>(R.id.slider_label).setText(label)
        val valueText = row.findViewById<TextView>(R.id.slider_value)
        val slider = row.findViewById<Slider>(R.id.slider)
        slider.valueFrom = from
        slider.valueTo = to
        slider.stepSize = step
        // The value must sit exactly on a step, otherwise the Slider throws an exception.
        val steps = ((value.coerceIn(from, to) - from) / step).roundToInt()
        slider.value = (from + steps * step).coerceIn(from, to)
        slider.contentDescription = getString(label)
        valueText.text = format(slider.value)
        slider.setLabelFormatter { format(it) }
        slider.addOnChangeListener { _, v, fromUser ->
            valueText.text = format(v)
            if (fromUser) onChange(v)
        }
        container.addView(row)
        return slider
    }

    /** Fills a single-choice chip group. */
    protected fun <T> bindChips(
        group: ChipGroup, items: List<T>, label: (T) -> String, selected: T, onSelect: (T) -> Unit
    ) {
        group.setOnCheckedStateChangeListener(null)
        group.removeAllViews()
        items.forEach { item ->
            val chip = layoutInflater.inflate(R.layout.item_chip, group, false) as Chip
            chip.id = View.generateViewId()
            chip.text = label(item)
            chip.tag = item
            group.addView(chip)
            if (item == selected) group.check(chip.id)
        }
        group.setOnCheckedStateChangeListener { g, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            val chip = g.findViewById<Chip>(id) ?: return@setOnCheckedStateChangeListener
            @Suppress("UNCHECKED_CAST")
            onSelect(chip.tag as T)
        }
    }
}
