package com.cuteisland.dynamicisland.island

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.AnticipateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import com.cuteisland.dynamicisland.model.AnimationStyle
import com.cuteisland.dynamicisland.model.EventKind
import com.cuteisland.dynamicisland.model.IslandAlignment
import com.cuteisland.dynamicisland.model.IslandEvent
import com.cuteisland.dynamicisland.model.IslandLook
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The animated Dynamic Island pill. It is used both in the floating overlay window and
 * inside the app screens as a live preview.
 *
 * Sequence: a small dot opens into the pill, the pill expands to the style's size, the
 * content fades in, it waits for the display time, then everything reverses.
 */
class IslandView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        const val SIDE_PAD_DP = 12f
        const val TOP_PAD_DP = 2f
        const val BOTTOM_PAD_DP = 10f
    }

    private val d = resources.displayMetrics.density
    val sidePadPx = SIDE_PAD_DP * d
    val topPadPx = TOP_PAD_DP * d
    val bottomPadPx = BOTTOM_PAD_DP * d

    var look: IslandLook = IslandLook.DEFAULT
        set(value) {
            field = value
            requestLayout()
            invalidate()
        }

    var event: IslandEvent? = null
        set(value) {
            field = value
            contentDescription = value?.let { "${it.title}. ${it.subtitle}" }
            requestLayout()
            invalidate()
        }

    /** Replays the animation forever. Used by the in-app previews. */
    var demoLoop = false

    /** Stays open after appearing. Used while editing the appearance. */
    var holdOpen = false

    /** When true the island opens only to the small pill size and does not expand. */
    var holdCollapsed = false

    /** Called after the closing animation finishes. */
    var onClosed: (() -> Unit)? = null

    val isPlaying: Boolean get() = playing

    // Animation state
    private var openP = 0f
    private var expandP = 0f
    private var contentA = 0f
    private var clock = 0f
    private var lastNanos = 0L
    private var playing = false
    private var openSet: AnimatorSet? = null
    private var closeSet: AnimatorSet? = null
    private val holdRunnable = Runnable { close() }
    private val loopRunnable = Runnable { play() }

    // Drawing tools
    private val pose = CharacterPose()
    private val rect = RectF()
    private val clipPath = Path()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFB4B4CC.toInt() }
    private val percentPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val ringTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    // ------------------------------------------------------------------ playback

    /** Starts the full open, hold and close sequence. */
    fun play() {
        if (event == null) return
        cancelAll()
        openP = 0f
        expandP = 0f
        contentA = 0f
        playing = true
        val steps = ArrayList<Animator>()
        steps.add(floatAnim(0f, 1f, dur(300), OvershootInterpolator(1.6f)) { openP = it })
        if (!holdCollapsed) {
            steps.add(floatAnim(0f, 1f, dur(420), OvershootInterpolator(1.1f)) { expandP = it })
        }
        steps.add(floatAnim(0f, 1f, dur(220), DecelerateInterpolator()) { contentA = it })
        openSet = AnimatorSet().apply {
            playSequentially(steps)
            addListener(onEnd {
                if (!holdOpen) postDelayed(holdRunnable, look.durationSec * 1000L)
            })
            start()
        }
        lastNanos = 0L
        invalidate()
    }

    /** Plays the closing animation now (for example, when the user taps the island). */
    fun close() {
        removeCallbacks(holdRunnable)
        if (!playing) return
        openSet?.cancel()
        openSet = null
        closeSet?.cancel()
        val steps = listOf<Animator>(
            floatAnim(contentA, 0f, dur(160), AccelerateInterpolator()) { contentA = it },
            floatAnim(expandP, 0f, dur(320), AnticipateInterpolator(0.6f)) { expandP = it },
            floatAnim(min(openP, 1f), 0f, dur(240), AccelerateInterpolator()) { openP = it }
        )
        closeSet = AnimatorSet().apply {
            playSequentially(steps)
            addListener(onEnd { finished() })
            start()
        }
    }

    /** Stops immediately without animation. */
    fun stop() {
        cancelAll()
        playing = false
        openP = 0f
        expandP = 0f
        contentA = 0f
        invalidate()
    }

    private fun finished() {
        playing = false
        openP = 0f
        expandP = 0f
        contentA = 0f
        invalidate()
        onClosed?.invoke()
        if (demoLoop && isAttachedToWindow) postDelayed(loopRunnable, 900L)
    }

    private fun cancelAll() {
        removeCallbacks(holdRunnable)
        removeCallbacks(loopRunnable)
        openSet?.cancel()
        closeSet?.cancel()
        openSet = null
        closeSet = null
    }

    private fun dur(ms: Long): Long = (ms / look.speed.coerceIn(0.25f, 3f)).toLong().coerceAtLeast(60L)

    private fun floatAnim(
        from: Float, to: Float, duration: Long, interp: TimeInterpolator, update: (Float) -> Unit
    ): ValueAnimator = ValueAnimator.ofFloat(from, to).apply {
        this.duration = duration
        interpolator = interp
        addUpdateListener {
            update(it.animatedValue as Float)
            invalidate()
        }
    }

    private fun onEnd(block: () -> Unit) = object : AnimatorListenerAdapter() {
        private var cancelled = false
        override fun onAnimationCancel(animation: Animator) {
            cancelled = true
        }

        override fun onAnimationEnd(animation: Animator) {
            if (!cancelled) block()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if ((demoLoop || holdOpen) && event != null && !playing) post { play() }
    }

    override fun onDetachedFromWindow() {
        cancelAll()
        playing = false
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ measuring

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val style = event?.style ?: AnimationStyle.EXPANDING
        val availW = if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.UNSPECIFIED) {
            resources.displayMetrics.widthPixels.toFloat()
        } else {
            MeasureSpec.getSize(widthMeasureSpec).toFloat()
        }
        val target = IslandGeometry.target(look, style, d, availW - sidePadPx * 2f)
        val desiredW = (target.width + sidePadPx * 2f).toInt()
        val desiredH = (target.height + topPadPx + bottomPadPx).toInt()
        setMeasuredDimension(
            resolveSize(desiredW, widthMeasureSpec),
            resolveSize(desiredH, heightMeasureSpec)
        )
    }

    // ------------------------------------------------------------------ drawing

    private fun tick() {
        val now = System.nanoTime()
        if (lastNanos != 0L) {
            val dt = ((now - lastNanos) / 1_000_000_000f).coerceAtMost(0.05f)
            clock += dt * look.speed
        }
        lastNanos = now
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val ev = event ?: return
        if (!playing && openP <= 0.001f) {
            lastNanos = 0L
            return
        }
        tick()

        val maxW = width - sidePadPx * 2f
        if (maxW <= 0f || height <= 0) return
        val ch = look.heightDp * d
        val cw = min(look.widthDp * d, maxW)
        val target = IslandGeometry.target(look, ev.style, d, maxW)
        val dot = ch * 0.45f
        val baseW = lerp(dot, cw, openP)
        val baseH = lerp(dot, ch, openP)
        val w = lerp(baseW, target.width, expandP).coerceIn(dot * 0.3f, width.toFloat())
        val h = lerp(baseH, target.height, expandP).coerceIn(dot * 0.3f, height.toFloat())
        val left = when (look.alignment) {
            IslandAlignment.LEFT -> sidePadPx
            IslandAlignment.RIGHT -> width - sidePadPx - w
            IslandAlignment.CENTER -> (width - w) / 2f
        }
        rect.set(left, topPadPx, left + w, topPadPx + h)
        val baseR = min(look.radiusDp * d, ch / 2f)
        val r = min(baseR * (h / ch).coerceIn(0.4f, 1.8f), h / 2f)
        val pillAlpha = (openP * 3f).coerceIn(0f, 1f)

        bgPaint.color = look.color
        bgPaint.alpha = (Color.alpha(look.color) * pillAlpha).toInt()
        canvas.drawRoundRect(rect, r, r, bgPaint)

        // Accent outline. The glowing style pulses brightly.
        val pulse = 0.5f + 0.5f * sin(clock * 3f)
        val glowing = ev.style == AnimationStyle.GLOWING
        val glow = expandP.coerceIn(0f, 1f) * (if (glowing) 0.5f + 0.5f * pulse else 0.35f)
        if (glow > 0.01f) {
            glowPaint.color = IslandEffects.withAlpha(ev.accent, (glow * 255 * pillAlpha).toInt())
            glowPaint.strokeWidth = (if (glowing) 2.5f else 1.2f) * d
            canvas.drawRoundRect(rect, r, r, glowPaint)
        }

        if (contentA > 0.01f) {
            val save = canvas.saveLayerAlpha(rect.left, rect.top, rect.right, rect.bottom, (contentA * 255).toInt())
            clipPath.reset()
            clipPath.addRoundRect(rect, r, r, Path.Direction.CW)
            canvas.clipPath(clipPath)
            pose.t = clock
            pose.mood = ev.mood
            pose.percent = ev.percent
            pose.charging = ev.kind == EventKind.CHARGING
            pose.walking = false
            pose.headOnly = false
            if (h < ch * 1.25f) drawCompact(canvas, ev, rect, r) else drawWide(canvas, ev, rect, r, ch)
            canvas.restoreToCount(save)
        }
        postInvalidateOnAnimation()
    }

    private fun drawCompact(c: Canvas, ev: IslandEvent, r: RectF, radius: Float) {
        val h = r.height()
        val pad = h * 0.14f
        val s = h - pad * 2f
        val inset = radius * 0.12f
        val iconCx = r.left + pad + inset + s / 2f
        pose.headOnly = true
        CharacterRenderer.draw(c, ev.character, iconCx, r.centerY(), s * 1.1f, pose)
        pose.headOnly = false

        val rightEdge = r.right - pad - inset
        val rightStart: Float
        if (ev.percent >= 0) {
            percentPaint.textSize = h * 0.42f
            percentPaint.color = ev.accent
            val txt = "${ev.percent}%"
            rightStart = rightEdge - percentPaint.measureText(txt)
            c.drawText(txt, rightStart, baseline(r.centerY(), percentPaint), percentPaint)
        } else {
            val iconSize = s * 0.75f
            rightStart = rightEdge - iconSize
            drawKindIcon(c, ev, rightStart + iconSize / 2f, r.centerY(), iconSize)
        }
        titlePaint.textSize = h * 0.34f
        val textLeft = iconCx + s * 0.6f + pad * 0.5f
        drawEllipsized(c, ev.title, textLeft, baseline(r.centerY(), titlePaint), rightStart - pad * 0.6f - textLeft, titlePaint)
    }

    private fun drawWide(c: Canvas, ev: IslandEvent, r: RectF, radius: Float, ch: Float) {
        val h = r.height()
        val pad = max(h * 0.12f, 5f * d)
        val inset = radius * 0.22f
        val contentLeft = r.left + pad + inset
        val contentRight = r.right - pad - inset
        if (ev.style == AnimationStyle.WALKING) {
            drawWalking(c, ev, r, contentLeft, contentRight)
            return
        }
        val s = h - pad * 2f
        val charCx = contentLeft + s / 2f
        val cy = r.centerY()

        // Left: the character
        val yOff = when (ev.style) {
            AnimationStyle.BOUNCING -> -abs(sin(clock * PI.toFloat() * 1.4f)) * s * 0.14f
            AnimationStyle.EXPANDING -> sin(clock * 2.2f) * s * 0.03f
            else -> sin(clock * 2f) * s * 0.02f
        }
        if (ev.style == AnimationStyle.BOUNCING) {
            val squeeze = 1f - abs(yOff) / (s * 0.14f + 0.001f) * 0.4f
            barPaint.color = 0x55000000
            c.drawOval(charCx - s * 0.25f * squeeze, cy + s * 0.44f, charCx + s * 0.25f * squeeze, cy + s * 0.5f, barPaint)
        }
        CharacterRenderer.draw(c, ev.character, charCx, cy + yOff, s, pose)

        // Right: battery, ring, waves or percentage
        val rw = min(s * 0.85f, (contentRight - contentLeft) * 0.28f)
        val rcx = contentRight - rw / 2f
        var rightLeft = contentRight - rw
        val charging = ev.kind == EventKind.CHARGING
        when (ev.style) {
            AnimationStyle.ELECTRIC -> {
                IslandEffects.drawSparks(c, rcx, cy, rw * 0.55f, clock, 0xFFFDE047.toInt())
                IslandEffects.drawBattery(c, rcx, cy, rw * 0.8f, ev.percent, ev.accent, 0f, charging || ev.kind == EventKind.FULLY_CHARGED)
            }
            AnimationStyle.GLOWING -> {
                IslandEffects.drawBattery(c, rcx, cy, rw * 0.85f, ev.percent, ev.accent, 0.4f + 0.6f * pulseAt(3f), charging)
            }
            AnimationStyle.BLUETOOTH -> {
                IslandEffects.drawWaves(c, rcx, cy, rw * 0.3f, clock, ev.accent)
                if (ev.percent >= 0) {
                    IslandEffects.drawRing(c, rcx, cy, rw * 0.3f, ev.percent, ev.accent, ringTextPaint)
                } else {
                    IslandEffects.drawBluetoothRune(c, rcx, cy, rw * 0.5f, ev.accent)
                }
            }
            AnimationStyle.EXPANDING -> {
                if (ev.percent >= 0) {
                    percentPaint.textSize = min(h, ch * 1.9f) * 0.36f
                    percentPaint.color = ev.accent
                    val txt = "${ev.percent}%"
                    val tw = percentPaint.measureText(txt)
                    rightLeft = contentRight - tw
                    c.drawText(txt, rightLeft, baseline(cy, percentPaint), percentPaint)
                } else {
                    val size = s * 0.4f
                    rightLeft = contentRight - size
                    drawKindIcon(c, ev, contentRight - size / 2f, cy, size)
                }
            }
            else -> {
                if (ev.percent >= 0) {
                    IslandEffects.drawRing(c, rcx, cy, rw * 0.38f, ev.percent, ev.accent, ringTextPaint)
                } else {
                    drawKindIcon(c, ev, rcx, cy, rw * 0.6f)
                }
            }
        }

        // Middle: title, subtitle and (for the expanding style) a progress bar
        val textLeft = charCx + s / 2f + pad * 0.8f
        val textRight = rightLeft - pad * 0.6f
        val maxText = textRight - textLeft
        val base = min(h, ch * 1.9f)
        titlePaint.textSize = base * 0.25f
        subPaint.textSize = base * 0.18f
        val showBar = ev.style == AnimationStyle.EXPANDING && ev.percent >= 0
        val barH = 5f * d
        val gap = base * 0.06f
        val block = titlePaint.textSize + gap + subPaint.textSize + if (showBar) gap * 2f + barH else 0f
        var y = cy - block / 2f
        drawEllipsized(c, ev.title, textLeft, y + titlePaint.textSize * 0.9f, maxText, titlePaint)
        y += titlePaint.textSize + gap
        drawEllipsized(c, ev.subtitle, textLeft, y + subPaint.textSize * 0.9f, maxText, subPaint)
        y += subPaint.textSize
        if (showBar && maxText > 10f * d) {
            y += gap * 2f
            barPaint.color = 0x33FFFFFF
            c.drawRoundRect(textLeft, y, textRight, y + barH, barH / 2f, barH / 2f, barPaint)
            val level = ev.percent / 100f
            val fillRight = textLeft + maxText * level
            barPaint.color = ev.accent
            c.drawRoundRect(textLeft, y, fillRight, y + barH, barH / 2f, barH / 2f, barPaint)
            if (charging && fillRight - textLeft > barH * 2f) {
                val sx = textLeft + ((clock * 0.6f) % 1f) * (fillRight - textLeft)
                barPaint.color = 0x88FFFFFF.toInt()
                c.drawCircle(sx, y + barH / 2f, barH * 0.7f, barPaint)
            }
        }
    }

    private fun drawWalking(c: Canvas, ev: IslandEvent, r: RectF, contentLeft: Float, contentRight: Float) {
        val h = r.height()
        val rowCy = r.top + h * 0.3f
        titlePaint.textSize = h * 0.2f
        // Percent or icon on the top right
        var rightStart = contentRight
        if (ev.percent >= 0) {
            percentPaint.textSize = h * 0.22f
            percentPaint.color = ev.accent
            val txt = "${ev.percent}%"
            rightStart = contentRight - percentPaint.measureText(txt)
            c.drawText(txt, rightStart, baseline(rowCy, percentPaint), percentPaint)
        } else {
            val size = h * 0.24f
            rightStart = contentRight - size
            drawKindIcon(c, ev, contentRight - size / 2f, rowCy, size)
        }
        val label = if (ev.isBluetooth && !ev.title.contains(ev.subtitle)) "${ev.title} · ${ev.subtitle}" else ev.title
        drawEllipsized(c, label, contentLeft, baseline(rowCy, titlePaint), rightStart - contentLeft - 6f * d, titlePaint)

        // Ground dots and the walking character
        val groundY = r.bottom - h * 0.1f
        barPaint.color = 0x33FFFFFF
        var gx = contentLeft
        while (gx < contentRight) {
            c.drawCircle(gx, groundY, 1.2f * d, barPaint)
            gx += 7f * d
        }
        val size = h * 0.56f
        val travel = contentRight - contentLeft + size
        val phase = (clock * 0.2f) % 1f
        val x = contentLeft - size / 2f + phase * travel
        pose.walking = true
        pose.walkPhase = clock * 10f
        val step = abs(sin(clock * 10f)) * size * 0.03f
        CharacterRenderer.draw(c, ev.character, x, groundY - size * 0.48f - step, size, pose)
        pose.walking = false
    }

    private fun drawKindIcon(c: Canvas, ev: IslandEvent, cx: Float, cy: Float, size: Float) {
        when (ev.kind) {
            EventKind.CHARGING, EventKind.FULLY_CHARGED -> IslandEffects.drawBolt(c, cx, cy, size, ev.accent)
            EventKind.CHARGER_DISCONNECTED -> IslandEffects.drawPlug(c, cx, cy, size, ev.accent)
            EventKind.BT_CONNECTED, EventKind.BT_DISCONNECTED ->
                IslandEffects.drawBluetoothRune(c, cx, cy, size, ev.accent)
        }
    }

    private fun pulseAt(speed: Float) = 0.5f + 0.5f * sin(clock * speed)

    private fun baseline(centerY: Float, p: Paint): Float {
        val fm = p.fontMetrics
        return centerY - (fm.ascent + fm.descent) / 2f
    }

    private fun drawEllipsized(c: Canvas, text: String, x: Float, baselineY: Float, maxW: Float, p: TextPaint) {
        if (maxW < 8f * d || text.isEmpty()) return
        val t = TextUtils.ellipsize(text, p, maxW, TextUtils.TruncateAt.END)
        if (t.isNotEmpty()) c.drawText(t, 0, t.length, x, baselineY, p)
    }

    private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f
}
