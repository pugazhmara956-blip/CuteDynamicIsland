package com.cuteisland.dynamicisland.island

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.cuteisland.dynamicisland.model.AnimationStyle
import com.cuteisland.dynamicisland.model.IslandLook
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Battery, lightning, Bluetooth and ring drawings used inside the island. */
object IslandEffects {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val rect = RectF()

    fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    fun drawBolt(c: Canvas, cx: Float, cy: Float, h: Float, color: Int) {
        val w = h * 0.7f
        val l = cx - w / 2f
        val t = cy - h / 2f
        path.reset()
        path.moveTo(l + w * 0.6f, t)
        path.lineTo(l + w * 0.05f, t + h * 0.56f)
        path.lineTo(l + w * 0.45f, t + h * 0.56f)
        path.lineTo(l + w * 0.35f, t + h)
        path.lineTo(l + w * 0.95f, t + h * 0.4f)
        path.lineTo(l + w * 0.55f, t + h * 0.4f)
        path.close()
        fill.color = color
        c.drawPath(path, fill)
    }

    /** Horizontal battery. [glow] from 0 to 1 adds a pulsing halo. */
    fun drawBattery(
        c: Canvas, cx: Float, cy: Float, width: Float, percent: Int, color: Int,
        glow: Float, charging: Boolean
    ) {
        val w = width
        val h = width * 0.5f
        val l = cx - w / 2f
        val t = cy - h / 2f
        val r = h * 0.26f
        if (glow > 0f) {
            for (i in 3 downTo 1) {
                fill.color = withAlpha(color, (glow * 38 / i).toInt())
                val g = h * 0.22f * i
                rect.set(l - g, t - g, l + w + g, t + h + g)
                c.drawRoundRect(rect, r + g, r + g, fill)
            }
        }
        // outline and cap
        stroke.color = withAlpha(Color.WHITE, 200)
        stroke.strokeWidth = h * 0.09f
        rect.set(l, t, l + w * 0.9f, t + h)
        c.drawRoundRect(rect, r, r, stroke)
        fill.color = withAlpha(Color.WHITE, 200)
        rect.set(l + w * 0.92f, t + h * 0.3f, l + w, t + h * 0.7f)
        c.drawRoundRect(rect, h * 0.08f, h * 0.08f, fill)
        // fill level
        val level = (if (percent >= 0) percent else 50).coerceIn(0, 100) / 100f
        val inset = h * 0.15f
        val innerW = (w * 0.9f - inset * 2f) * level
        if (innerW > 0.5f) {
            fill.color = color
            rect.set(l + inset, t + inset, l + inset + innerW, t + h - inset)
            c.drawRoundRect(rect, r * 0.6f, r * 0.6f, fill)
        }
        if (charging) drawBolt(c, l + w * 0.45f, cy, h * 0.78f, Color.WHITE)
    }

    /** Flickering electric sparks around a point. */
    fun drawSparks(c: Canvas, cx: Float, cy: Float, radius: Float, t: Float, color: Int) {
        stroke.color = color
        stroke.strokeWidth = radius * 0.07f
        for (i in 0 until 6) {
            if (sin(t * 23f + i * 1.7f) < 0.1f) continue
            val a = Math.toRadians((i * 60.0 + t * 50.0)).toFloat()
            val ca = cos(a)
            val sa = sin(a)
            val r0 = radius * 0.78f
            val r1 = radius * 1.25f
            val jitter = radius * 0.1f
            path.reset()
            path.moveTo(cx + ca * r0, cy + sa * r0)
            for (k in 1..3) {
                val f = r0 + (r1 - r0) * k / 3f
                val side = if (k % 2 == 0) jitter else -jitter
                path.lineTo(cx + ca * f - sa * side, cy + sa * f + ca * side)
            }
            c.drawPath(path, stroke)
        }
    }

    fun drawBluetoothRune(c: Canvas, cx: Float, cy: Float, h: Float, color: Int) {
        val w = h * 0.55f
        val l = cx - w / 2f
        val t = cy - h / 2f
        stroke.color = color
        stroke.strokeWidth = h * 0.1f
        path.reset()
        path.moveTo(l, t + h * 0.28f)
        path.lineTo(l + w, t + h * 0.72f)
        path.lineTo(l + w * 0.5f, t + h)
        path.lineTo(l + w * 0.5f, t)
        path.lineTo(l + w, t + h * 0.28f)
        path.lineTo(l, t + h * 0.72f)
        c.drawPath(path, stroke)
    }

    /** Ripples of Bluetooth waves on both sides of a point. */
    fun drawWaves(c: Canvas, cx: Float, cy: Float, baseR: Float, t: Float, color: Int) {
        for (i in 0 until 3) {
            val phase = (t * 0.8f + i / 3f) % 1f
            val r = baseR * (1f + phase * 0.9f)
            stroke.color = withAlpha(color, ((1f - phase) * 210).toInt())
            stroke.strokeWidth = baseR * 0.12f
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(rect, -40f, 80f, false, stroke)
            c.drawArc(rect, 140f, 80f, false, stroke)
        }
    }

    /** Circular progress ring with the percentage in the middle. */
    fun drawRing(c: Canvas, cx: Float, cy: Float, radius: Float, percent: Int, color: Int, textPaint: Paint) {
        stroke.strokeWidth = radius * 0.2f
        stroke.color = withAlpha(Color.WHITE, 40)
        c.drawCircle(cx, cy, radius, stroke)
        stroke.color = color
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)
        c.drawArc(rect, -90f, 360f * percent.coerceIn(0, 100) / 100f, false, stroke)
        textPaint.textSize = radius * 0.72f
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = Color.WHITE
        val text = percent.coerceIn(0, 100).toString()
        val fm = textPaint.fontMetrics
        c.drawText(text, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    fun drawPlug(c: Canvas, cx: Float, cy: Float, h: Float, color: Int) {
        val w = h * 0.55f
        fill.color = color
        rect.set(cx - w / 2f, cy - h * 0.15f, cx + w / 2f, cy + h * 0.25f)
        c.drawRoundRect(rect, w * 0.2f, w * 0.2f, fill)
        stroke.color = color
        stroke.strokeWidth = h * 0.09f
        c.drawLine(cx - w * 0.22f, cy - h * 0.15f, cx - w * 0.22f, cy - h * 0.42f, stroke)
        c.drawLine(cx + w * 0.22f, cy - h * 0.15f, cx + w * 0.22f, cy - h * 0.42f, stroke)
        c.drawLine(cx, cy + h * 0.25f, cx, cy + h * 0.48f, stroke)
    }
}

/** Calculates how big the island is in each state. Shared by the overlay and previews. */
object IslandGeometry {

    data class PillSize(val width: Float, val height: Float)

    fun collapsed(look: IslandLook, density: Float) =
        PillSize(look.widthDp * density, look.heightDp * density)

    fun target(look: IslandLook, style: AnimationStyle, density: Float, maxWidth: Float): PillSize {
        val cw = look.widthDp * density
        val ch = look.heightDp * density
        val (w, h) = when (style) {
            AnimationStyle.SMALL_PILL -> cw * 1.5f to ch
            AnimationStyle.EXPANDING -> cw * 2.6f to ch * 2.9f
            else -> cw * 2.25f to ch * 1.75f
        }
        val limit = if (maxWidth > 0f) maxWidth else w
        return PillSize(min(w, limit).coerceAtLeast(min(cw, limit)), h)
    }
}
