package com.cuteisland.dynamicisland.island

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import com.cuteisland.dynamicisland.model.CharacterType
import com.cuteisland.dynamicisland.model.Mood
import kotlin.math.min
import kotlin.math.sin

/** Shows one animated character. Used in the Character Collection screen. */
class CharacterView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var character: CharacterType = CharacterType.KITTEN
        set(value) {
            field = value
            contentDescription = context.getString(value.nameRes)
            invalidate()
        }

    var mood: Mood = Mood.HAPPY
        set(value) {
            field = value
            invalidate()
        }

    private val pose = CharacterPose()
    private val startTime = SystemClock.uptimeMillis()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        pose.t = (SystemClock.uptimeMillis() - startTime) / 1000f
        pose.mood = mood
        pose.percent = 70
        pose.charging = true
        pose.headOnly = false
        pose.walking = false
        val size = min(width, height) * 0.86f
        val bounce = sin(pose.t * 2.4f) * size * 0.02f
        CharacterRenderer.draw(canvas, character, width / 2f, height / 2f + bounce, size, pose)
        if (isShown) postInvalidateOnAnimation()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) invalidate()
    }
}
