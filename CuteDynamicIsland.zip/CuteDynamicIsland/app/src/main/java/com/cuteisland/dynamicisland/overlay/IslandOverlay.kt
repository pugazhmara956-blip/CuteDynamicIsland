package com.cuteisland.dynamicisland.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import com.cuteisland.dynamicisland.data.IslandSettings
import com.cuteisland.dynamicisland.island.IslandGeometry
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.IslandAlignment
import com.cuteisland.dynamicisland.model.IslandEvent

/**
 * Adds the island to the screen with WindowManager (TYPE_APPLICATION_OVERLAY) and removes it
 * when the animation ends. The window is only as big as the island, and it exists only while
 * an animation is playing, so it never blocks touches for long.
 */
object IslandOverlay {

    private const val TAG = "IslandOverlay"

    private val handler = Handler(Looper.getMainLooper())
    private var view: IslandView? = null
    private var windowManager: WindowManager? = null
    private val safetyRemove = Runnable { removeNow() }

    val isShowing: Boolean get() = view != null

    /** Shows the event on top of other apps. Returns false if it could not be shown. */
    fun show(context: Context, event: IslandEvent): Boolean {
        val app = context.applicationContext
        if (!Settings.canDrawOverlays(app)) return false
        removeNow()

        val look = IslandSettings(app).look()
        val wm = app.getSystemService(WindowManager::class.java) ?: return false
        val density = app.resources.displayMetrics.density
        val screenW = screenWidth(wm, app)

        val island = IslandView(app)
        val target = IslandGeometry.target(look, event.style, density, screenW - island.sidePadPx * 2f)
        val winW = (target.width + island.sidePadPx * 2f).toInt().coerceAtMost(screenW)
        val winH = (target.height + island.topPadPx + island.bottomPadPx).toInt()

        island.look = look
        island.event = event
        island.onClosed = { removeNow() }
        island.setOnClickListener { island.close() }

        val params = WindowManager.LayoutParams(
            winW,
            winH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or when (look.alignment) {
                IslandAlignment.LEFT -> Gravity.START
                IslandAlignment.CENTER -> Gravity.CENTER_HORIZONTAL
                IslandAlignment.RIGHT -> Gravity.END
            }
            x = 0
            y = ((look.offsetYDp * density) - island.topPadPx).toInt().coerceAtLeast(0)
            title = "CuteDynamicIsland"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        return try {
            wm.addView(island, params)
            view = island
            windowManager = wm
            island.play()
            // Safety net in case the closing callback never arrives.
            val maxMs = look.durationSec * 1000L + (3000L / look.speed).toLong() + 3000L
            handler.postDelayed(safetyRemove, maxMs)
            true
        } catch (e: Exception) {
            // Thrown when the system refuses the window (for example, permission revoked).
            Log.w(TAG, "Could not add the island window", e)
            false
        }
    }

    /** Updates the text of the island that is already showing (for example, a battery level). */
    fun update(event: IslandEvent) {
        val v = view ?: return
        val current = v.event ?: return
        if (current.kind == event.kind && current.deviceAddress == event.deviceAddress) {
            v.event = event
        }
    }

    fun removeNow() {
        handler.removeCallbacks(safetyRemove)
        val v = view ?: return
        view = null
        v.onClosed = null
        v.stop()
        try {
            windowManager?.removeViewImmediate(v)
        } catch (e: Exception) {
            Log.w(TAG, "Island window was already removed", e)
        }
        windowManager = null
    }

    private fun screenWidth(wm: WindowManager, context: Context): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wm.currentWindowMetrics.bounds.width()
        } else {
            context.resources.displayMetrics.widthPixels
        }
}
