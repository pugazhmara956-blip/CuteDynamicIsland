package com.cuteisland.dynamicisland.model

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.data.IslandSettings

/** Builds island events with English text and the user's chosen style and character. */
object EventFactory {

    const val ACCENT_GREEN = 0xFF34D399.toInt()
    const val ACCENT_CYAN = 0xFF22D3EE.toInt()
    const val ACCENT_AMBER = 0xFFFBBF24.toInt()
    const val ACCENT_BLUE = 0xFF60A5FA.toInt()
    const val ACCENT_PINK = 0xFFF472B6.toInt()
    const val ACCENT_RED = 0xFFF87171.toInt()

    fun charging(ctx: Context, s: IslandSettings, percent: Int, plugType: Int): IslandEvent {
        val sub = when (plugType) {
            BatteryManager.BATTERY_PLUGGED_AC -> R.string.sub_charging_ac
            BatteryManager.BATTERY_PLUGGED_USB -> R.string.sub_charging_usb
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> R.string.sub_charging_wireless
            else -> R.string.sub_charging
        }
        return IslandEvent(
            EventKind.CHARGING, ctx.getString(R.string.title_charging), ctx.getString(sub),
            percent, s.chargingStyle, s.chargingCharacter, ACCENT_GREEN, Mood.HAPPY
        )
    }

    fun unplugged(ctx: Context, s: IslandSettings, percent: Int): IslandEvent = IslandEvent(
        EventKind.CHARGER_DISCONNECTED, ctx.getString(R.string.title_unplugged),
        ctx.getString(R.string.sub_unplugged, percent.coerceIn(0, 100)),
        percent, s.chargingStyle, s.chargingCharacter, ACCENT_AMBER, Mood.SAD
    )

    fun fullyCharged(ctx: Context, s: IslandSettings): IslandEvent = IslandEvent(
        EventKind.FULLY_CHARGED, ctx.getString(R.string.title_full), ctx.getString(R.string.sub_full),
        100, s.chargingStyle, s.chargingCharacter, ACCENT_CYAN, Mood.EXCITED
    )

    fun btConnected(
        ctx: Context, s: IslandSettings, name: String, isAirPods: Boolean, percent: Int, address: String?
    ): IslandEvent = IslandEvent(
        EventKind.BT_CONNECTED,
        ctx.getString(if (isAirPods) R.string.title_airpods_connected else R.string.title_bt_connected),
        name, if (s.btShowBattery) percent else -1, s.btStyle, s.btCharacter,
        if (isAirPods) ACCENT_PINK else ACCENT_BLUE, Mood.HAPPY, address
    )

    fun btDisconnected(
        ctx: Context, s: IslandSettings, name: String, isAirPods: Boolean, address: String?
    ): IslandEvent = IslandEvent(
        EventKind.BT_DISCONNECTED,
        ctx.getString(if (isAirPods) R.string.title_airpods_disconnected else R.string.title_bt_disconnected),
        name, -1, s.btStyle, s.btCharacter, ACCENT_RED, Mood.SAD, address
    )

    /** Sample events used by test buttons and previews. */
    enum class Sample { CHARGING, FULL, UNPLUGGED, AIRPODS, DEVICE, DISCONNECTED }

    fun sample(ctx: Context, s: IslandSettings, sample: Sample): IslandEvent {
        val level = currentBatteryLevel(ctx)
        return when (sample) {
            Sample.CHARGING -> charging(ctx, s, level, BatteryManager.BATTERY_PLUGGED_AC)
            Sample.FULL -> fullyCharged(ctx, s)
            Sample.UNPLUGGED -> unplugged(ctx, s, level)
            Sample.AIRPODS -> btConnected(ctx, s, ctx.getString(R.string.sample_airpods_name), true, 80, null)
            Sample.DEVICE -> btConnected(ctx, s, ctx.getString(R.string.sample_device_name), false, 65, null)
            Sample.DISCONNECTED -> btDisconnected(ctx, s, ctx.getString(R.string.sample_airpods_name), true, null)
        }
    }

    /** Reads the current battery level without any permission (sticky broadcast). */
    fun currentBatteryLevel(ctx: Context): Int {
        val intent: Intent? = ctx.applicationContext.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        return batteryPercent(intent)
    }

    fun batteryPercent(intent: Intent?): Int {
        if (intent == null) return -1
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return -1
        return (level * 100f / scale).toInt().coerceIn(0, 100)
    }
}
