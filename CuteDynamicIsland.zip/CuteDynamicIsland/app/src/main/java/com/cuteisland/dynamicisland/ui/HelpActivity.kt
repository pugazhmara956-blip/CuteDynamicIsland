package com.cuteisland.dynamicisland.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.cuteisland.dynamicisland.R

/** Plain English help, Xiaomi tips and honest Android limitations. */
class HelpActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)
        setupToolbar(R.string.help_title)
        findViewById<TextView>(R.id.intro_text).visibility = View.GONE

        val sections = listOf(
            R.string.help_how_title to R.string.help_how_body,
            R.string.help_setup_title to R.string.help_setup_body,
            R.string.help_xiaomi_title to R.string.help_xiaomi_body,
            R.string.help_test_title to R.string.help_test_body,
            R.string.help_limits_title to R.string.help_limits_body,
            R.string.help_privacy_title to R.string.help_privacy_body
        )
        val container = findViewById<LinearLayout>(R.id.container)
        sections.forEach { (heading, body) ->
            val card = layoutInflater.inflate(R.layout.item_help_section, container, false)
            card.findViewById<TextView>(R.id.help_heading).setText(heading)
            card.findViewById<TextView>(R.id.help_body).setText(body)
            container.addView(card)
        }
    }
}
