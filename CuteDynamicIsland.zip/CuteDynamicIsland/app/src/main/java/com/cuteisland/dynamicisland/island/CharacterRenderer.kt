package com.cuteisland.dynamicisland.island

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.cuteisland.dynamicisland.model.CharacterType
import com.cuteisland.dynamicisland.model.Mood
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Animation state passed to the renderer on every frame. */
class CharacterPose {
    /** Animation clock in seconds. */
    var t = 0f
    var mood = Mood.HAPPY
    var walking = false
    var walkPhase = 0f
    /** Draw only the head (used inside the small pill). */
    var headOnly = false
    var percent = -1
    var charging = false
}

/**
 * Draws every character with simple shapes. All artwork is original and created in code,
 * so the app needs no image files and works fully offline.
 * All drawing happens on the main thread, so the shared paint objects are safe.
 */
object CharacterRenderer {

    private const val DARK = 0xFF2B1B3D.toInt()
    private const val PINK = 0xFFFF8FB8.toInt()
    private const val CHEEK = 0x99FF7AA8.toInt()
    private const val WHITE = Color.WHITE

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val oval = RectF()

    fun draw(c: Canvas, type: CharacterType, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        if (size <= 2f) return
        when (type) {
            CharacterType.CAT_AND_MOUSE -> drawCatAndMouse(c, cx, cy, size, pose)
            CharacterType.KITTEN -> drawKitten(c, cx, cy, size, pose, 0xFFF6A04D.toInt(), 0xFFD9772A.toInt())
            CharacterType.PUPPY -> drawPuppy(c, cx, cy, size, pose)
            CharacterType.PANDA -> drawPanda(c, cx, cy, size, pose)
            CharacterType.TEDDY -> drawTeddy(c, cx, cy, size, pose)
            CharacterType.BUNNY -> drawBunny(c, cx, cy, size, pose)
            CharacterType.ANIME_GIRL -> drawAnimeGirl(c, cx, cy, size, pose)
            CharacterType.HEARTS -> drawHearts(c, cx, cy, size, pose)
            CharacterType.BATTERY_BUDDY -> drawBatteryBuddy(c, cx, cy, size, pose)
            CharacterType.FUNNY_BLOB -> drawBlob(c, cx, cy, size, pose)
            CharacterType.EARBUD_BUDDY -> drawEarbud(c, cx, cy, size, pose)
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun headRadius(size: Float, pose: CharacterPose) =
        if (pose.headOnly) size * 0.34f else size * 0.27f

    private fun headY(cy: Float, size: Float, pose: CharacterPose) =
        if (pose.headOnly) cy + size * 0.07f else cy - size * 0.08f

    private fun shade(color: Int, factor: Float): Int = Color.argb(
        Color.alpha(color),
        (Color.red(color) * factor).toInt().coerceIn(0, 255),
        (Color.green(color) * factor).toInt().coerceIn(0, 255),
        (Color.blue(color) * factor).toInt().coerceIn(0, 255)
    )

    private fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fill.color = color
        c.drawCircle(x, y, r, fill)
    }

    private fun ovalAt(c: Canvas, x: Float, y: Float, rx: Float, ry: Float, color: Int) {
        fill.color = color
        oval.set(x - rx, y - ry, x + rx, y + ry)
        c.drawOval(oval, fill)
    }

    private fun triangle(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, color: Int) {
        fill.color = color
        path.reset()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.close()
        c.drawPath(path, fill)
    }

    /** Small round body with feet and arms. Feet swing while walking. */
    private fun drawBody(
        c: Canvas, cx: Float, hy: Float, r: Float, pose: CharacterPose,
        color: Int, belly: Int? = null, limbs: Int = shade(color, 0.85f)
    ) {
        val by = hy + r * 1.1f
        val swing = if (pose.walking) sin(pose.walkPhase) * r * 0.28f else 0f
        val lift = if (pose.walking) abs(cos(pose.walkPhase)) * r * 0.08f else 0f
        // feet
        ovalAt(c, cx - r * 0.38f + swing, by + r * 0.5f - lift, r * 0.24f, r * 0.15f, limbs)
        ovalAt(c, cx + r * 0.38f - swing, by + r * 0.5f, r * 0.24f, r * 0.15f, limbs)
        // arms (wave when excited)
        val wave = if (pose.mood == Mood.EXCITED) sin(pose.t * 10f) * r * 0.18f else 0f
        ovalAt(c, cx - r * 0.66f, by - r * 0.05f - wave, r * 0.16f, r * 0.26f, limbs)
        ovalAt(c, cx + r * 0.66f, by - r * 0.05f + wave, r * 0.16f, r * 0.26f, limbs)
        // torso
        ovalAt(c, cx, by, r * 0.62f, r * 0.52f, color)
        if (belly != null) ovalAt(c, cx, by + r * 0.08f, r * 0.38f, r * 0.32f, belly)
    }

    /** Eyes, mouth and cheeks shared by most characters. */
    private fun drawFace(
        c: Canvas, cx: Float, hy: Float, r: Float, pose: CharacterPose,
        eyeColor: Int = DARK, spacing: Float = 0.36f, mouthY: Float = 0.24f, cheeks: Boolean = true,
        eyeY: Float = 0f
    ) {
        val ex = r * spacing
        val ey = hy + r * eyeY
        val er = r * 0.11f
        val blink = (pose.t % 3.4f) < 0.14f
        stroke.color = eyeColor
        stroke.strokeWidth = r * 0.075f
        when {
            pose.mood == Mood.EXCITED -> {
                // happy closed eyes: ^ ^
                for (sx in floatArrayOf(-1f, 1f)) {
                    path.reset()
                    path.moveTo(cx + sx * ex - er, ey + er * 0.4f)
                    path.lineTo(cx + sx * ex, ey - er * 0.6f)
                    path.lineTo(cx + sx * ex + er, ey + er * 0.4f)
                    c.drawPath(path, stroke)
                }
            }
            blink -> {
                c.drawLine(cx - ex - er, ey, cx - ex + er, ey, stroke)
                c.drawLine(cx + ex - er, ey, cx + ex + er, ey, stroke)
            }
            else -> {
                circle(c, cx - ex, ey, er, eyeColor)
                circle(c, cx + ex, ey, er, eyeColor)
                val hl = if (eyeColor == WHITE) DARK else WHITE
                circle(c, cx - ex + er * 0.35f, ey - er * 0.35f, er * 0.35f, hl)
                circle(c, cx + ex + er * 0.35f, ey - er * 0.35f, er * 0.35f, hl)
            }
        }
        if (pose.mood == Mood.SAD) {
            // eyebrows and a small tear
            stroke.color = DARK
            stroke.strokeWidth = r * 0.05f
            c.drawLine(cx - ex - er, ey - er * 1.9f, cx - ex + er, ey - er * 2.4f, stroke)
            c.drawLine(cx + ex + er, ey - er * 1.9f, cx + ex - er, ey - er * 2.4f, stroke)
            val drop = (pose.t * 0.8f) % 1f
            ovalAt(c, cx + ex + er * 0.4f, ey + er * 1.6f + drop * r * 0.35f, er * 0.38f, er * 0.55f, 0xFF7DD3FC.toInt())
        }
        // mouth
        val my = hy + r * mouthY
        val mw = r * 0.16f
        stroke.color = DARK
        stroke.strokeWidth = r * 0.06f
        when (pose.mood) {
            Mood.HAPPY -> {
                oval.set(cx - mw, my - mw * 0.9f, cx + mw, my + mw * 0.6f)
                c.drawArc(oval, 20f, 140f, false, stroke)
            }
            Mood.EXCITED -> {
                fill.color = DARK
                oval.set(cx - mw, my - mw * 0.7f, cx + mw, my + mw * 1.1f)
                c.drawArc(oval, 0f, 180f, true, fill)
                ovalAt(c, cx, my + mw * 0.55f, mw * 0.55f, mw * 0.3f, PINK)
            }
            Mood.SAD -> {
                oval.set(cx - mw * 0.8f, my, cx + mw * 0.8f, my + mw * 1.2f)
                c.drawArc(oval, 200f, 140f, false, stroke)
            }
        }
        if (cheeks) {
            ovalAt(c, cx - r * 0.62f, hy + r * 0.2f, r * 0.14f, r * 0.08f, CHEEK)
            ovalAt(c, cx + r * 0.62f, hy + r * 0.2f, r * 0.14f, r * 0.08f, CHEEK)
        }
    }

    private fun whiskers(c: Canvas, cx: Float, y: Float, r: Float, color: Int) {
        stroke.color = color
        stroke.strokeWidth = r * 0.035f
        for (i in -1..1) {
            val dy = i * r * 0.1f
            c.drawLine(cx - r * 0.45f, y + dy * 0.5f, cx - r * 1.05f, y + dy * 1.6f, stroke)
            c.drawLine(cx + r * 0.45f, y + dy * 0.5f, cx + r * 1.05f, y + dy * 1.6f, stroke)
        }
    }

    fun heartPath(p: Path, cx: Float, cy: Float, s: Float) {
        p.reset()
        p.moveTo(cx, cy + s * 0.38f)
        p.cubicTo(cx - s * 0.62f, cy - s * 0.02f, cx - s * 0.38f, cy - s * 0.55f, cx, cy - s * 0.22f)
        p.cubicTo(cx + s * 0.38f, cy - s * 0.55f, cx + s * 0.62f, cy - s * 0.02f, cx, cy + s * 0.38f)
        p.close()
    }

    private fun star(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        path.reset()
        for (i in 0 until 10) {
            val rr = if (i % 2 == 0) r else r * 0.45f
            val a = Math.toRadians((i * 36 - 90).toDouble())
            val x = cx + (cos(a) * rr).toFloat()
            val y = cy + (sin(a) * rr).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = color
        c.drawPath(path, fill)
    }

    // ------------------------------------------------------------------ characters

    private fun drawKitten(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose, color: Int, stripe: Int) {
        val r = headRadius(size, pose)
        val hy = headY(cy, size, pose)
        val cream = 0xFFFFE8CC.toInt()
        if (!pose.headOnly) {
            // swishing tail
            stroke.color = color
            stroke.strokeWidth = r * 0.2f
            val sw = sin(pose.t * 3f) * r * 0.35f
            path.reset()
            path.moveTo(cx + r * 0.4f, hy + r * 1.35f)
            path.quadTo(cx + r * 1.3f, hy + r * 1.2f, cx + r * 1.1f + sw, hy + r * 0.45f)
            c.drawPath(path, stroke)
            drawBody(c, cx, hy, r, pose, color, cream)
        }
        // ears
        triangle(c, cx - r * 0.92f, hy - r * 0.25f, cx - r * 0.7f, hy - r * 1.2f, cx - r * 0.12f, hy - r * 0.82f, color)
        triangle(c, cx + r * 0.92f, hy - r * 0.25f, cx + r * 0.7f, hy - r * 1.2f, cx + r * 0.12f, hy - r * 0.82f, color)
        triangle(c, cx - r * 0.75f, hy - r * 0.42f, cx - r * 0.66f, hy - r * 0.98f, cx - r * 0.32f, hy - r * 0.76f, PINK)
        triangle(c, cx + r * 0.75f, hy - r * 0.42f, cx + r * 0.66f, hy - r * 0.98f, cx + r * 0.32f, hy - r * 0.76f, PINK)
        circle(c, cx, hy, r, color)
        // forehead stripes
        stroke.color = stripe
        stroke.strokeWidth = r * 0.09f
        c.drawLine(cx, hy - r * 0.95f, cx, hy - r * 0.62f, stroke)
        c.drawLine(cx - r * 0.25f, hy - r * 0.9f, cx - r * 0.2f, hy - r * 0.64f, stroke)
        c.drawLine(cx + r * 0.25f, hy - r * 0.9f, cx + r * 0.2f, hy - r * 0.64f, stroke)
        ovalAt(c, cx, hy + r * 0.3f, r * 0.42f, r * 0.3f, cream)
        drawFace(c, cx, hy, r, pose, mouthY = 0.32f)
        triangle(c, cx - r * 0.09f, hy + r * 0.12f, cx + r * 0.09f, hy + r * 0.12f, cx, hy + r * 0.22f, PINK)
        whiskers(c, cx, hy + r * 0.24f, r, 0xCCFFFFFF.toInt())
    }

    private fun drawMouse(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val r = headRadius(size, pose)
        val hy = headY(cy, size, pose)
        val grey = 0xFFA3A9B8.toInt()
        if (!pose.headOnly) {
            stroke.color = 0xFFE9A6B8.toInt()
            stroke.strokeWidth = r * 0.1f
            val sw = sin(pose.t * 5f) * r * 0.3f
            path.reset()
            path.moveTo(cx - r * 0.4f, hy + r * 1.4f)
            path.cubicTo(cx - r * 1.3f, hy + r * 1.6f, cx - r * 1.2f, hy + r * 0.6f + sw, cx - r * 1.5f, hy + r * 0.5f)
            c.drawPath(path, stroke)
            drawBody(c, cx, hy, r, pose, grey, 0xFFE5E7EB.toInt())
        }
        circle(c, cx - r * 0.8f, hy - r * 0.72f, r * 0.5f, grey)
        circle(c, cx + r * 0.8f, hy - r * 0.72f, r * 0.5f, grey)
        circle(c, cx - r * 0.8f, hy - r * 0.72f, r * 0.32f, PINK)
        circle(c, cx + r * 0.8f, hy - r * 0.72f, r * 0.32f, PINK)
        circle(c, cx, hy, r, grey)
        drawFace(c, cx, hy, r, pose, mouthY = 0.36f)
        circle(c, cx, hy + r * 0.2f, r * 0.1f, PINK)
        whiskers(c, cx, hy + r * 0.24f, r, 0xCCFFFFFF.toInt())
    }

    private fun drawCatAndMouse(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val wasWalking = pose.walking
        val oldPhase = pose.walkPhase
        if (pose.headOnly) {
            drawKitten(c, cx - size * 0.16f, cy, size * 0.78f, pose, 0xFFF59E42.toInt(), 0xFFC96A1B.toInt())
            drawMouse(c, cx + size * 0.3f, cy + size * 0.12f, size * 0.5f, pose)
            return
        }
        pose.walking = true
        pose.walkPhase = pose.t * 12f
        val chase = sin(pose.t * 2f) * size * 0.05f
        val hop = abs(sin(pose.t * 9f)) * size * 0.05f
        drawKitten(c, cx - size * 0.2f + chase, cy + size * 0.04f, size * 0.74f, pose, 0xFFF59E42.toInt(), 0xFFC96A1B.toInt())
        val mx = cx + size * 0.3f
        val my = cy + size * 0.16f - hop
        drawMouse(c, mx, my, size * 0.42f, pose)
        // a slice of cheese held by the mouse
        val s = size * 0.12f
        triangle(c, mx + s * 0.8f, my + s * 0.6f, mx + s * 2.0f, my + s * 0.6f, mx + s * 2.0f, my - s * 0.4f, 0xFFFCD34D.toInt())
        circle(c, mx + s * 1.7f, my + s * 0.25f, s * 0.15f, 0xFFF59E0B.toInt())
        pose.walking = wasWalking
        pose.walkPhase = oldPhase
    }

    private fun drawPuppy(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val r = headRadius(size, pose)
        val hy = headY(cy, size, pose)
        val fur = 0xFFE8C39E.toInt()
        val ear = 0xFF9C6B3E.toInt()
        if (!pose.headOnly) drawBody(c, cx, hy, r, pose, fur, 0xFFF7E3CC.toInt())
        val flap = sin(pose.t * 4f) * 6f
        for (side in intArrayOf(-1, 1)) {
            c.save()
            c.rotate(side * (22f + flap), cx + side * r * 0.82f, hy - r * 0.5f)
            ovalAt(c, cx + side * r * 0.9f, hy + r * 0.05f, r * 0.26f, r * 0.58f, ear)
            c.restore()
        }
        circle(c, cx, hy, r, fur)
        circle(c, cx + r * 0.36f, hy, r * 0.25f, 0xFFC99A6B.toInt())
        ovalAt(c, cx, hy + r * 0.36f, r * 0.42f, r * 0.3f, 0xFFF7E3CC.toInt())
        drawFace(c, cx, hy, r, pose, mouthY = 0.42f)
        ovalAt(c, cx, hy + r * 0.2f, r * 0.13f, r * 0.09f, DARK)
        if (pose.mood == Mood.HAPPY) ovalAt(c, cx + r * 0.05f, hy + r * 0.58f, r * 0.09f, r * 0.12f, PINK)
    }

    private fun drawPanda(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val r = headRadius(size, pose)
        val hy = headY(cy, size, pose)
        val white = 0xFFF8F8F8.toInt()
        val black = 0xFF1F1F2A.toInt()
        if (!pose.headOnly) drawBody(c, cx, hy, r, pose, white, null, black)
        circle(c, cx - r * 0.74f, hy - r * 0.72f, r * 0.3f, black)
        circle(c, cx + r * 0.74f, hy - r * 0.72f, r * 0.3f, black)
        circle(c, cx, hy, r, white)
        for (side in intArrayOf(-1, 1)) {
            c.save()
            c.rotate(side * -25f, cx + side * r * 0.36f, hy)
            ovalAt(c, cx + side * r * 0.36f, hy + r * 0.02f, r * 0.2f, r * 0.27f, black)
            c.restore()
        }
        drawFace(c, cx, hy, r, pose, eyeColor = WHITE, mouthY = 0.36f)
        ovalAt(c, cx, hy + r * 0.2f, r * 0.11f, r * 0.07f, black)
    }

    private fun drawTeddy(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val r = headRadius(size, pose)
        val hy = headY(cy, size, pose)
        val fur = 0xFFB9835A.toInt()
        val tan = 0xFFE9C9A3.toInt()
        if (!pose.headOnly) {
            drawBody(c, cx, hy, r, pose, fur, tan)
            // red bow tie
            val by = hy + r * 0.95f
            triangle(c, cx, by, cx - r * 0.3f, by - r * 0.16f, cx - r * 0.3f, by + r * 0.16f, 0xFFEF4444.toInt())
            triangle(c, cx, by, cx + r * 0.3f, by - r * 0.16f, cx + r * 0.3f, by + r * 0.16f, 0xFFEF4444.toInt())
            circle(c, cx, by, r * 0.07f, 0xFFB91C1C.toInt())
        }
        circle(c, cx - r * 0.76f, hy - r * 0.7f, r * 0.32f, fur)
        circle(c, cx + r * 0.76f, hy - r * 0.7f, r * 0.32f, fur)
        circle(c, cx - r * 0.76f, hy - r * 0.7f, r * 0.18f, tan)
        circle(c, cx + r * 0.76f, hy - r * 0.7f, r * 0.18f, tan)
        circle(c, cx, hy, r, fur)
        ovalAt(c, cx, hy + r * 0.34f, r * 0.4f, r * 0.3f, tan)
        drawFace(c, cx, hy, r, pose, mouthY = 0.44f)
        ovalAt(c, cx, hy + r * 0.24f, r * 0.13f, r * 0.09f, DARK)
    }

    private fun drawBunny(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val r = headRadius(size, pose) * 0.92f
        val hy = headY(cy, size, pose) + r * 0.2f
        val fur = 0xFFF3F0FF.toInt()
        if (!pose.headOnly) drawBody(c, cx, hy, r, pose, fur, WHITE, 0xFFE4DEF7.toInt())
        val wiggle = sin(pose.t * 3f) * 7f
        for (side in intArrayOf(-1, 1)) {
            c.save()
            c.rotate(side * (10f + wiggle * side), cx + side * r * 0.35f, hy - r * 0.8f)
            ovalAt(c, cx + side * r * 0.35f, hy - r * 1.45f, r * 0.24f, r * 0.7f, fur)
            ovalAt(c, cx + side * r * 0.35f, hy - r * 1.42f, r * 0.12f, r * 0.52f, PINK)
            c.restore()
        }
        circle(c, cx, hy, r, fur)
        drawFace(c, cx, hy, r, pose, mouthY = 0.3f)
        circle(c, cx, hy + r * 0.17f, r * 0.08f, PINK)
        // little teeth
        if (pose.mood != Mood.EXCITED) {
            fill.color = WHITE
            c.drawRect(cx - r * 0.08f, hy + r * 0.36f, cx + r * 0.08f, hy + r * 0.5f, fill)
            stroke.color = 0x55000000
            stroke.strokeWidth = r * 0.02f
            c.drawLine(cx, hy + r * 0.36f, cx, hy + r * 0.5f, stroke)
        }
    }

    private fun drawAnimeGirl(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val r = headRadius(size, pose)
        val hy = headY(cy, size, pose)
        val skin = 0xFFFFE3D3.toInt()
        val hair = 0xFFB794F4.toInt()
        val hairDark = 0xFF8B5CF6.toInt()
        // long hair behind the head
        fill.color = hair
        oval.set(cx - r * 1.12f, hy - r * 1.08f, cx + r * 1.12f, hy + r * (if (pose.headOnly) 1.0f else 1.45f))
        c.drawRoundRect(oval, r, r, fill)
        if (!pose.headOnly) drawBody(c, cx, hy, r, pose, 0xFFF472B6.toInt(), 0xFFFBCFE8.toInt(), skin)
        circle(c, cx, hy, r, skin)
        // bangs
        path.reset()
        path.moveTo(cx - r * 1.04f, hy + r * 0.05f)
        path.quadTo(cx - r * 1.05f, hy - r * 1.2f, cx, hy - r * 1.1f)
        path.quadTo(cx + r * 1.05f, hy - r * 1.2f, cx + r * 1.04f, hy + r * 0.05f)
        path.lineTo(cx + r * 0.78f, hy - r * 0.42f)
        path.lineTo(cx + r * 0.5f, hy - r * 0.18f)
        path.lineTo(cx + r * 0.26f, hy - r * 0.5f)
        path.lineTo(cx, hy - r * 0.22f)
        path.lineTo(cx - r * 0.26f, hy - r * 0.5f)
        path.lineTo(cx - r * 0.5f, hy - r * 0.18f)
        path.lineTo(cx - r * 0.78f, hy - r * 0.42f)
        path.close()
        fill.color = hair
        c.drawPath(path, fill)
        // big sparkly eyes
        val ex = r * 0.38f
        val ey = hy + r * 0.14f
        val blink = (pose.t % 3.6f) < 0.14f
        stroke.color = DARK
        stroke.strokeWidth = r * 0.07f
        for (side in floatArrayOf(-1f, 1f)) {
            val x = cx + side * ex
            when {
                pose.mood == Mood.EXCITED -> {
                    oval.set(x - r * 0.17f, ey - r * 0.12f, x + r * 0.17f, ey + r * 0.16f)
                    c.drawArc(oval, 200f, 140f, false, stroke)
                }
                blink -> {
                    oval.set(x - r * 0.17f, ey - r * 0.14f, x + r * 0.17f, ey + r * 0.06f)
                    c.drawArc(oval, 20f, 140f, false, stroke)
                }
                else -> {
                    ovalAt(c, x, ey, r * 0.17f, r * 0.23f, WHITE)
                    ovalAt(c, x, ey + r * 0.02f, r * 0.14f, r * 0.2f, hairDark)
                    ovalAt(c, x, ey + r * 0.06f, r * 0.07f, r * 0.1f, DARK)
                    circle(c, x + r * 0.05f, ey - r * 0.07f, r * 0.055f, WHITE)
                    circle(c, x - r * 0.05f, ey + r * 0.1f, r * 0.03f, WHITE)
                    // upper eyelash line
                    oval.set(x - r * 0.19f, ey - r * 0.25f, x + r * 0.19f, ey + r * 0.2f)
                    c.drawArc(oval, 200f, 140f, false, stroke)
                }
            }
        }
        if (pose.mood == Mood.SAD) {
            val drop = (pose.t * 0.8f) % 1f
            ovalAt(c, cx + ex + r * 0.1f, ey + r * 0.28f + drop * r * 0.3f, r * 0.05f, r * 0.08f, 0xFF7DD3FC.toInt())
        }
        // mouth
        stroke.strokeWidth = r * 0.05f
        val my = hy + r * 0.48f
        oval.set(cx - r * 0.09f, my - r * 0.08f, cx + r * 0.09f, my + r * 0.06f)
        if (pose.mood == Mood.SAD) c.drawArc(oval, 200f, 140f, false, stroke) else c.drawArc(oval, 20f, 140f, false, stroke)
        // blush lines
        stroke.color = 0xAAFF7AA8.toInt()
        stroke.strokeWidth = r * 0.035f
        for (side in floatArrayOf(-1f, 1f)) {
            val bx = cx + side * r * 0.62f
            c.drawLine(bx - r * 0.1f, hy + r * 0.38f, bx - r * 0.04f, hy + r * 0.32f, stroke)
            c.drawLine(bx + r * 0.0f, hy + r * 0.38f, bx + r * 0.06f, hy + r * 0.32f, stroke)
        }
        // star hair clip
        val twinkle = 1f + 0.12f * sin(pose.t * 5f)
        star(c, cx + r * 0.66f, hy - r * 0.68f, r * 0.2f * twinkle, 0xFFFCD34D.toInt())
    }

    private fun drawHearts(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val colors = intArrayOf(0xFFFF4D8D.toInt(), 0xFFF472B6.toInt(), 0xFFC084FC.toInt(), 0xFFFB7185.toInt())
        if (!pose.headOnly) {
            for (i in 0 until 4) {
                val phase = (pose.t * 0.45f + i * 0.25f) % 1f
                val x = cx + sin(i * 2.1f + pose.t * 1.8f) * size * 0.36f
                val y = cy + size * 0.42f - phase * size * 0.9f
                fill.color = colors[i]
                fill.alpha = ((1f - phase) * 230).toInt()
                heartPath(path, x, y, size * 0.17f)
                c.drawPath(path, fill)
                fill.alpha = 255
            }
        }
        val beat = 1f + 0.09f * sin(pose.t * 7f).coerceAtLeast(0f)
        val s = size * (if (pose.headOnly) 0.95f else 0.66f) * beat
        val hy = cy + size * 0.02f
        fill.color = 0xFFFF4D8D.toInt()
        heartPath(path, cx, hy, s)
        c.drawPath(path, fill)
        fill.color = 0x66FFFFFF
        ovalAt(c, cx - s * 0.22f, hy - s * 0.18f, s * 0.08f, s * 0.05f, 0x66FFFFFF)
        drawFace(c, cx, hy - s * 0.02f, s * 0.42f, pose, mouthY = 0.3f, spacing = 0.42f)
    }

    private fun drawBatteryBuddy(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val bw = size * (if (pose.headOnly) 0.62f else 0.46f)
        val bh = size * (if (pose.headOnly) 0.78f else 0.6f)
        val top = cy - bh * 0.62f
        val left = cx - bw / 2f
        val radius = bw * 0.22f
        val level = (if (pose.percent >= 0) pose.percent else 60) / 100f
        if (!pose.headOnly) {
            // legs
            stroke.color = 0xFF059669.toInt()
            stroke.strokeWidth = bw * 0.09f
            val swing = if (pose.walking) sin(pose.walkPhase) * bw * 0.15f else 0f
            c.drawLine(cx - bw * 0.2f, top + bh, cx - bw * 0.22f + swing, top + bh + size * 0.14f, stroke)
            c.drawLine(cx + bw * 0.2f, top + bh, cx + bw * 0.22f - swing, top + bh + size * 0.14f, stroke)
            // arms
            val wave = sin(pose.t * (if (pose.mood == Mood.EXCITED) 10f else 3f)) * bw * 0.2f
            c.drawLine(left, top + bh * 0.55f, left - bw * 0.3f, top + bh * 0.35f - wave, stroke)
            c.drawLine(left + bw, top + bh * 0.55f, left + bw + bw * 0.3f, top + bh * 0.35f + wave, stroke)
        }
        // cap
        fill.color = 0xFF059669.toInt()
        oval.set(cx - bw * 0.18f, top - bh * 0.08f, cx + bw * 0.18f, top + bh * 0.04f)
        c.drawRoundRect(oval, bw * 0.05f, bw * 0.05f, fill)
        // body
        fill.color = 0xFFA7F3D0.toInt()
        oval.set(left, top, left + bw, top + bh)
        c.drawRoundRect(oval, radius, radius, fill)
        // energy level
        c.save()
        c.clipRect(left, top + bh * (1f - level), left + bw, top + bh)
        fill.color = 0xFF34D399.toInt()
        c.drawRoundRect(oval, radius, radius, fill)
        c.restore()
        stroke.color = 0xFF059669.toInt()
        stroke.strokeWidth = bw * 0.06f
        c.drawRoundRect(oval, radius, radius, stroke)
        drawFace(c, cx, top + bh * 0.36f, bw * 0.48f, pose, mouthY = 0.36f, spacing = 0.42f)
        if (pose.charging || pose.mood == Mood.EXCITED) {
            IslandEffects.drawBolt(c, cx, top + bh * 0.76f, bh * 0.26f, 0xFFFCD34D.toInt())
        }
    }

    private fun drawBlob(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val base = size * (if (pose.headOnly) 0.42f else 0.36f)
        val by = cy + size * 0.06f
        path.reset()
        val n = 32
        for (i in 0..n) {
            val a = (i.toFloat() / n) * 2f * Math.PI.toFloat()
            val wob = 1f + 0.06f * sin(4f * a + pose.t * 5f) + 0.03f * sin(7f * a - pose.t * 3f)
            val squash = if (sin(a) > 0) 0.88f else 1f
            val x = cx + cos(a) * base * wob
            val y = by + sin(a) * base * wob * squash
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = 0xFFA78BFA.toInt()
        c.drawPath(path, fill)
        ovalAt(c, cx - base * 0.35f, by - base * 0.45f, base * 0.18f, base * 0.1f, 0x55FFFFFF)
        // googly eyes
        val er = base * 0.24f
        val px = sin(pose.t * 3f) * er * 0.35f
        val py = cos(pose.t * 2.3f) * er * 0.3f
        for (side in floatArrayOf(-1f, 1f)) {
            val ex = cx + side * base * 0.36f
            val ey = by - base * 0.2f
            circle(c, ex, ey, er, WHITE)
            circle(c, ex + px, ey + py + (if (pose.mood == Mood.SAD) er * 0.3f else 0f), er * 0.48f, DARK)
        }
        // mouth with a cheeky tongue
        val my = by + base * 0.3f
        fill.color = DARK
        oval.set(cx - base * 0.28f, my - base * 0.12f, cx + base * 0.28f, my + base * 0.22f)
        if (pose.mood == Mood.SAD) {
            stroke.color = DARK
            stroke.strokeWidth = base * 0.07f
            c.drawArc(oval, 200f, 140f, false, stroke)
        } else {
            c.drawArc(oval, 0f, 180f, true, fill)
            ovalAt(c, cx + base * 0.06f, my + base * 0.2f + sin(pose.t * 6f) * base * 0.03f, base * 0.12f, base * 0.14f, PINK)
        }
    }

    private fun drawEarbud(c: Canvas, cx: Float, cy: Float, size: Float, pose: CharacterPose) {
        val r = if (pose.headOnly) size * 0.32f else size * 0.26f
        val hx = cx - r * 0.25f
        val hy = cy - (if (pose.headOnly) size * 0.06f else size * 0.14f)
        val white = 0xFFF8FAFC.toInt()
        val grey = 0xFFCBD5E1.toInt()
        val bob = sin(pose.t * 3f) * r * 0.06f
        // stem
        fill.color = white
        val stemBottom = hy + r * (if (pose.headOnly) 1.4f else 2.1f)
        oval.set(hx + r * 0.28f, hy + r * 0.1f + bob, hx + r * 0.8f, stemBottom + bob)
        c.drawRoundRect(oval, r * 0.26f, r * 0.26f, fill)
        fill.color = grey
        oval.set(hx + r * 0.36f, stemBottom - r * 0.22f + bob, hx + r * 0.72f, stemBottom - r * 0.06f + bob)
        c.drawRoundRect(oval, r * 0.08f, r * 0.08f, fill)
        // head
        circle(c, hx, hy + bob, r, white)
        circle(c, hx - r * 0.55f, hy - r * 0.42f + bob, r * 0.16f, 0xFF475569.toInt())
        ovalAt(c, hx + r * 0.3f, hy - r * 0.55f + bob, r * 0.2f, r * 0.1f, grey)
        drawFace(c, hx, hy + bob + r * 0.05f, r, pose, mouthY = 0.3f)
        // music waves
        if (!pose.headOnly) {
            for (i in 0 until 2) {
                val phase = (pose.t * 0.9f + i * 0.5f) % 1f
                stroke.color = 0xFF60A5FA.toInt()
                stroke.alpha = ((1f - phase) * 255).toInt()
                stroke.strokeWidth = r * 0.08f
                val rr = r * (1.25f + phase * 0.6f)
                oval.set(hx - rr, hy - rr + bob, hx + rr, hy + rr + bob)
                c.drawArc(oval, -60f, 50f, false, stroke)
                stroke.alpha = 255
            }
        }
    }
}
