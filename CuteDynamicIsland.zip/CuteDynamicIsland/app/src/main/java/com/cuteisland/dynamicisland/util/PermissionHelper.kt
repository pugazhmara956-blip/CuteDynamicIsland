package com.cuteisland.dynamicisland.util

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Checks and opens every permission the app uses. */
object PermissionHelper {

    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun hasBluetoothPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    fun hasNotificationPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun isIgnoringBatteryOptimizations(context: Context): Boolean =
        context.getSystemService(PowerManager::class.java)
            ?.isIgnoringBatteryOptimizations(context.packageName) == true

    fun overlaySettingsIntent(context: Context) =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))

    @SuppressLint("BatteryLife")
    fun batteryOptimizationIntent(context: Context) =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}"))

    fun appDetailsIntent(context: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
}

/** Opens Xiaomi (MIUI and HyperOS) specific settings pages, with safe fallbacks. */
object XiaomiHelper {

    private const val SECURITY_CENTER = "com.miui.securitycenter"

    fun isXiaomi(): Boolean {
        val maker = Build.MANUFACTURER.lowercase()
        val brand = Build.BRAND.lowercase()
        return maker.contains("xiaomi") || brand in setOf("xiaomi", "redmi", "poco")
    }

    fun autostartIntents(context: Context): List<Intent> = listOf(
        Intent().setComponent(
            ComponentName(SECURITY_CENTER, "com.miui.permcenter.autostart.AutoStartManagementActivity")
        ),
        PermissionHelper.appDetailsIntent(context)
    )

    fun otherPermissionsIntents(context: Context): List<Intent> = listOf(
        Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName(SECURITY_CENTER, "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", context.packageName),
        Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName(SECURITY_CENTER, "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
            .putExtra("extra_pkgname", context.packageName),
        PermissionHelper.appDetailsIntent(context)
    )

    /**
     * Opens the first page that exists. Returns true if a Xiaomi page opened, or false if
     * only the fallback (or nothing) could be opened.
     */
    fun openFirstAvailable(activity: Activity, intents: List<Intent>): Boolean {
        intents.forEachIndexed { index, intent ->
            try {
                activity.startActivity(intent)
                return index < intents.lastIndex
            } catch (e: Exception) {
                // Try the next option.
            }
        }
        return false
    }
}
