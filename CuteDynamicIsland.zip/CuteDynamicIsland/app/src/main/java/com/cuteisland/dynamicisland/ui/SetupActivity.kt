package com.cuteisland.dynamicisland.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.service.IslandService
import com.cuteisland.dynamicisland.util.PermissionHelper
import com.cuteisland.dynamicisland.util.XiaomiHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Explains and requests every permission, including the Xiaomi background settings. */
class SetupActivity : BaseActivity() {

    private enum class Status { ALLOWED, NOT_ALLOWED, NOT_NEEDED, MANUAL }

    private class Step(
        @StringRes val title: Int,
        @StringRes val desc: Int,
        @StringRes val button: Int,
        val status: () -> Status,
        val action: () -> Unit
    ) {
        lateinit var statusView: TextView
        lateinit var buttonView: MaterialButton
    }

    private val steps = ArrayList<Step>()

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> afterPermission(granted, Manifest.permission.POST_NOTIFICATIONS) }

    private val bluetoothPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> afterPermission(granted, Manifest.permission.BLUETOOTH_CONNECT) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)
        setupToolbar(R.string.setup_title)
        findViewById<TextView>(R.id.intro_text).setText(R.string.setup_intro)

        steps.add(Step(R.string.step_overlay, R.string.step_overlay_desc, R.string.allow,
            { if (PermissionHelper.canDrawOverlays(this)) Status.ALLOWED else Status.NOT_ALLOWED },
            { openSettings(PermissionHelper.overlaySettingsIntent(this)) }))

        steps.add(Step(R.string.step_notifications, R.string.step_notifications_desc, R.string.allow,
            {
                when {
                    Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU -> Status.NOT_NEEDED
                    PermissionHelper.hasNotificationPermission(this) -> Status.ALLOWED
                    else -> Status.NOT_ALLOWED
                }
            },
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    explainThen(R.string.notif_rationale) {
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }))

        steps.add(Step(R.string.step_bluetooth, R.string.step_bluetooth_desc, R.string.allow,
            {
                when {
                    Build.VERSION.SDK_INT < Build.VERSION_CODES.S -> Status.NOT_NEEDED
                    PermissionHelper.hasBluetoothPermission(this) -> Status.ALLOWED
                    else -> Status.NOT_ALLOWED
                }
            },
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    explainThen(R.string.bt_rationale) {
                        bluetoothPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
                    }
                }
            }))

        steps.add(Step(R.string.step_battery, R.string.step_battery_desc, R.string.allow,
            { if (PermissionHelper.isIgnoringBatteryOptimizations(this)) Status.ALLOWED else Status.NOT_ALLOWED },
            {
                try {
                    startActivity(PermissionHelper.batteryOptimizationIntent(this))
                } catch (e: Exception) {
                    openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }))

        if (XiaomiHelper.isXiaomi()) {
            steps.add(Step(R.string.step_autostart, R.string.step_autostart_desc, R.string.open,
                { Status.MANUAL },
                { openXiaomi(XiaomiHelper.autostartIntents(this)) }))
            steps.add(Step(R.string.step_popups, R.string.step_popups_desc, R.string.open,
                { Status.MANUAL },
                { openXiaomi(XiaomiHelper.otherPermissionsIntents(this)) }))
            steps.add(Step(R.string.step_lock, R.string.step_lock_desc, R.string.show_me_how,
                { Status.MANUAL },
                { open(HelpActivity::class.java) }))
        }

        val container = findViewById<LinearLayout>(R.id.container)
        steps.forEach { step ->
            val card = layoutInflater.inflate(R.layout.item_setup_step, container, false)
            card.findViewById<TextView>(R.id.step_title).setText(step.title)
            card.findViewById<TextView>(R.id.step_desc).setText(step.desc)
            step.statusView = card.findViewById(R.id.step_status)
            step.buttonView = card.findViewById(R.id.step_button)
            step.buttonView.setText(step.button)
            step.buttonView.contentDescription = getString(step.title)
            step.buttonView.setOnClickListener { step.action() }
            container.addView(card)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        // Once the overlay permission is granted, start the service if the user wants it on.
        if (settings.masterEnabled && PermissionHelper.canDrawOverlays(this) && !IslandService.isRunning) {
            IslandService.start(this)
        }
    }

    private fun refresh() {
        steps.forEach { step ->
            val status = step.status()
            val (text, color) = when (status) {
                Status.ALLOWED -> R.string.status_allowed to R.color.accent_green
                Status.NOT_ALLOWED -> R.string.status_not_allowed to R.color.accent_amber
                Status.NOT_NEEDED -> R.string.status_not_needed to R.color.text_muted
                Status.MANUAL -> R.string.status_check_manually to R.color.accent_cyan
            }
            step.statusView.setText(text)
            step.statusView.setTextColor(getColor(color))
            step.buttonView.visibility =
                if (status == Status.ALLOWED || status == Status.NOT_NEEDED) View.GONE else View.VISIBLE
        }
    }

    private fun explainThen(@StringRes message: Int, onAllow: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.permission_rationale_title)
            .setMessage(message)
            .setPositiveButton(R.string.allow) { _, _ -> onAllow() }
            .setNegativeButton(R.string.not_now, null)
            .show()
    }

    private fun afterPermission(granted: Boolean, permission: String) {
        if (!granted && !shouldShowRequestPermissionRationale(permission)) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.permission_rationale_title)
                .setMessage(R.string.permission_denied_body)
                .setPositiveButton(R.string.open_settings) { _, _ ->
                    openSettings(PermissionHelper.appDetailsIntent(this))
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
        refresh()
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(PermissionHelper.appDetailsIntent(this))
                Toast.makeText(this, R.string.settings_open_failed, Toast.LENGTH_LONG).show()
            } catch (ignored: Exception) {
                // No settings screen available; nothing more we can do.
            }
        }
    }

    private fun openXiaomi(intents: List<Intent>) {
        if (!XiaomiHelper.openFirstAvailable(this, intents)) {
            Toast.makeText(this, R.string.settings_open_failed, Toast.LENGTH_LONG).show()
        }
    }
}
