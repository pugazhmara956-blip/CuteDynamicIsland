package com.cuteisland.dynamicisland.data

import android.content.Context
import android.content.SharedPreferences
import com.cuteisland.dynamicisland.model.AnimationStyle
import com.cuteisland.dynamicisland.model.CharacterType
import com.cuteisland.dynamicisland.model.IslandAlignment
import com.cuteisland.dynamicisland.model.IslandLook

/** Saves every user choice locally on the phone with SharedPreferences. */
class IslandSettings(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun bool(key: String, def: Boolean) = prefs.getBoolean(key, def)
    private fun putBool(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()
    private fun int(key: String, def: Int) = prefs.getInt(key, def)
    private fun putInt(key: String, value: Int) = prefs.edit().putInt(key, value).apply()

    // ---- General ----
    var masterEnabled: Boolean
        get() = bool("master_enabled", true)
        set(value) = putBool("master_enabled", value)

    // ---- Battery ----
    var chargingEnabled: Boolean
        get() = bool("charging_enabled", true)
        set(value) = putBool("charging_enabled", value)

    var unpluggedEnabled: Boolean
        get() = bool("unplugged_enabled", true)
        set(value) = putBool("unplugged_enabled", value)

    var fullChargeEnabled: Boolean
        get() = bool("full_enabled", true)
        set(value) = putBool("full_enabled", value)

    var chargingStyle: AnimationStyle
        get() = AnimationStyle.fromName(prefs.getString("charging_style", null), AnimationStyle.ELECTRIC)
        set(value) = prefs.edit().putString("charging_style", value.name).apply()

    var chargingCharacter: CharacterType
        get() = CharacterType.fromName(prefs.getString("charging_character", null), CharacterType.KITTEN)
        set(value) = prefs.edit().putString("charging_character", value.name).apply()

    // ---- Bluetooth ----
    var bluetoothEnabled: Boolean
        get() = bool("bt_enabled", true)
        set(value) = putBool("bt_enabled", value)

    var btDisconnectEnabled: Boolean
        get() = bool("bt_disconnect_enabled", true)
        set(value) = putBool("bt_disconnect_enabled", value)

    var btAllDevices: Boolean
        get() = bool("bt_all_devices", true)
        set(value) = putBool("bt_all_devices", value)

    var btShowBattery: Boolean
        get() = bool("bt_show_battery", true)
        set(value) = putBool("bt_show_battery", value)

    var btStyle: AnimationStyle
        get() = AnimationStyle.fromName(prefs.getString("bt_style", null), AnimationStyle.BLUETOOTH)
        set(value) = prefs.edit().putString("bt_style", value.name).apply()

    var btCharacter: CharacterType
        get() = CharacterType.fromName(prefs.getString("bt_character", null), CharacterType.EARBUD_BUDDY)
        set(value) = prefs.edit().putString("bt_character", value.name).apply()

    // ---- Appearance ----
    var widthDp: Int
        get() = int("width_dp", IslandLook.DEFAULT_WIDTH)
        set(value) = putInt("width_dp", value)

    var heightDp: Int
        get() = int("height_dp", IslandLook.DEFAULT_HEIGHT)
        set(value) = putInt("height_dp", value)

    var radiusDp: Int
        get() = int("radius_dp", IslandLook.DEFAULT_RADIUS)
        set(value) = putInt("radius_dp", value)

    var color: Int
        get() = int("color", IslandLook.DEFAULT_COLOR)
        set(value) = putInt("color", value)

    var speed: Float
        get() = prefs.getFloat("speed", IslandLook.DEFAULT_SPEED)
        set(value) = prefs.edit().putFloat("speed", value).apply()

    var offsetYDp: Int
        get() = int("offset_y_dp", IslandLook.DEFAULT_OFFSET)
        set(value) = putInt("offset_y_dp", value)

    var durationSec: Int
        get() = int("duration_sec", IslandLook.DEFAULT_DURATION)
        set(value) = putInt("duration_sec", value)

    var alignment: IslandAlignment
        get() = IslandAlignment.fromName(prefs.getString("alignment", null))
        set(value) = prefs.edit().putString("alignment", value.name).apply()

    fun look(): IslandLook = IslandLook(
        widthDp = widthDp.coerceIn(80, 240),
        heightDp = heightDp.coerceIn(24, 56),
        radiusDp = radiusDp.coerceIn(0, 28),
        color = color,
        speed = speed.coerceIn(0.5f, 2.0f),
        alignment = alignment,
        offsetYDp = offsetYDp.coerceIn(0, 300),
        durationSec = durationSec.coerceIn(2, 10)
    )

    fun resetAppearance() {
        prefs.edit()
            .remove("width_dp").remove("height_dp").remove("radius_dp").remove("color")
            .remove("speed").remove("offset_y_dp").remove("duration_sec").remove("alignment")
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "island_settings"
    }
}
