package com.cuteisland.dynamicisland.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.cuteisland.dynamicisland.data.IslandSettings
import com.cuteisland.dynamicisland.service.IslandService

/** Starts the island service again after the phone restarts or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (IslandSettings(context).masterEnabled) {
            IslandService.start(context)
        }
    }
}
