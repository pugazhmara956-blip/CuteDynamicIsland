package com.cuteisland.dynamicisland.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.data.IslandSettings
import com.cuteisland.dynamicisland.model.EventFactory
import com.cuteisland.dynamicisland.model.IslandEvent
import com.cuteisland.dynamicisland.overlay.IslandOverlay
import com.cuteisland.dynamicisland.ui.MainActivity
import com.cuteisland.dynamicisland.util.PermissionHelper

/**
 * A lightweight foreground service. It does no polling: it only waits for charger and
 * Bluetooth broadcasts from Android, so its battery use is very small.
 */
class IslandService : Service(), BatteryMonitor.Listener, BluetoothMonitor.Listener {

    companion object {
        private const val TAG = "IslandService"
        private const val CHANNEL_ID = "island_service"
        private const val NOTIFICATION_ID = 1001
        private const val BATTERY_UPDATE_WINDOW_MS = 15_000L
        const val ACTION_START = "com.cuteisland.dynamicisland.action.START"
        const val ACTION_PAUSE = "com.cuteisland.dynamicisland.action.PAUSE"

        @Volatile
        var isRunning = false
            private set

        /** Starts the service. Returns false when it cannot start yet. */
        fun start(context: Context): Boolean {
            if (!PermissionHelper.canDrawOverlays(context)) return false
            return try {
                val intent = Intent(context, IslandService::class.java).setAction(ACTION_START)
                ContextCompat.startForegroundService(context, intent)
                true
            } catch (e: Exception) {
                // Android may refuse to start services from the background in rare cases.
                Log.w(TAG, "Could not start the island service", e)
                false
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, IslandService::class.java))
        }
    }

    private lateinit var settings: IslandSettings
    private lateinit var battery: BatteryMonitor
    private lateinit var bluetooth: BluetoothMonitor
    private var lastBtEvent: IslandEvent? = null
    private var lastBtTime = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = IslandSettings(this)
        createChannel()
        goForeground()
        battery = BatteryMonitor(this, this).also { it.start() }
        bluetooth = BluetoothMonitor(this, this).also { it.start() }
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PAUSE) {
            settings.masterEnabled = false
            shutDown()
            return START_NOT_STICKY
        }
        goForeground()
        if (!PermissionHelper.canDrawOverlays(this) || !settings.masterEnabled) {
            shutDown()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        battery.stop()
        bluetooth.stop()
        IslandOverlay.removeNow()
        isRunning = false
        super.onDestroy()
    }

    private fun shutDown() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------ battery events

    override fun onChargerConnected(percent: Int, plugType: Int) {
        if (!settings.masterEnabled || !settings.chargingEnabled) return
        IslandOverlay.show(this, EventFactory.charging(this, settings, percent, plugType))
    }

    override fun onChargerDisconnected(percent: Int) {
        if (!settings.masterEnabled || !settings.unpluggedEnabled) return
        IslandOverlay.show(this, EventFactory.unplugged(this, settings, percent))
    }

    override fun onFullyCharged() {
        if (!settings.masterEnabled || !settings.fullChargeEnabled) return
        IslandOverlay.show(this, EventFactory.fullyCharged(this, settings))
    }

    // ------------------------------------------------------------------ Bluetooth events

    override fun onDeviceConnected(device: BluetoothMonitor.DeviceInfo) {
        if (!settings.masterEnabled || !settings.bluetoothEnabled) return
        if (!settings.btAllDevices && !device.isAudio) return
        val name = device.name ?: getString(R.string.unknown_device)
        val event = EventFactory.btConnected(this, settings, name, device.isAirPods, device.battery, device.address)
        lastBtEvent = event
        lastBtTime = SystemClock.elapsedRealtime()
        IslandOverlay.show(this, event)
    }

    override fun onDeviceDisconnected(device: BluetoothMonitor.DeviceInfo) {
        if (!settings.masterEnabled || !settings.btDisconnectEnabled) return
        if (!settings.btAllDevices && !device.isAudio) return
        val name = device.name ?: getString(R.string.unknown_device)
        IslandOverlay.show(this, EventFactory.btDisconnected(this, settings, name, device.isAirPods, device.address))
    }

    override fun onBatteryLevel(address: String, level: Int) {
        val event = lastBtEvent ?: return
        if (event.deviceAddress != address || !settings.btShowBattery) return
        if (SystemClock.elapsedRealtime() - lastBtTime > BATTERY_UPDATE_WINDOW_MS) return
        val updated = event.copy(percent = level)
        lastBtEvent = updated
        IslandOverlay.update(updated)
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = getString(R.string.channel_desc)
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val pause = PendingIntent.getService(
            this, 1,
            Intent(this, IslandService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openApp)
            .addAction(0, getString(R.string.notif_pause), pause)
            .build()
    }

    private fun goForeground() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
        } catch (e: Exception) {
            Log.w(TAG, "Could not enter the foreground state", e)
            stopSelf()
        }
    }
}
