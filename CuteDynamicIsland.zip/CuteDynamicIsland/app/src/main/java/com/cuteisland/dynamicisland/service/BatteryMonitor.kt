package com.cuteisland.dynamicisland.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import com.cuteisland.dynamicisland.model.EventFactory

/**
 * Listens for charger events with BatteryManager broadcasts. These broadcasts cannot be
 * declared in the manifest on modern Android, so they are registered while the service runs.
 * No permission is needed to read battery information.
 */
class BatteryMonitor(
    private val context: Context,
    private val listener: Listener
) {

    interface Listener {
        fun onChargerConnected(percent: Int, plugType: Int)
        fun onChargerDisconnected(percent: Int)
        fun onFullyCharged()
    }

    private var fullShownThisSession = false
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    val sticky = currentBatteryIntent()
                    val percent = EventFactory.batteryPercent(sticky)
                    val plug = sticky?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                    fullShownThisSession = percent >= 100
                    listener.onChargerConnected(percent, plug)
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    fullShownThisSession = false
                    listener.onChargerDisconnected(EventFactory.batteryPercent(currentBatteryIntent()))
                }
                Intent.ACTION_BATTERY_CHANGED -> {
                    val percent = EventFactory.batteryPercent(intent)
                    val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val full = percent >= 100 || status == BatteryManager.BATTERY_STATUS_FULL
                    if (isInitialStickyBroadcast) {
                        // The current state when the service starts: remember it, do not announce it.
                        fullShownThisSession = plugged && full
                        return
                    }
                    if (plugged && full && !fullShownThisSession) {
                        fullShownThisSession = true
                        listener.onFullyCharged()
                    }
                    if (!plugged) fullShownThisSession = false
                }
            }
        }
    }

    fun start() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
    }

    fun stop() {
        if (!registered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (ignored: IllegalArgumentException) {
            // Already unregistered.
        }
        registered = false
    }

    private fun currentBatteryIntent(): Intent? =
        context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
}
