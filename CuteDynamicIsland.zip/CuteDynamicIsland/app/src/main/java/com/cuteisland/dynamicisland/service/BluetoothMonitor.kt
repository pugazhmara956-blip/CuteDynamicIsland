package com.cuteisland.dynamicisland.service

import android.annotation.SuppressLint
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.cuteisland.dynamicisland.util.PermissionHelper

/**
 * Listens for Bluetooth connections with the standard Android Bluetooth broadcasts.
 *
 * AirPods are treated as normal Bluetooth headphones. They are recognised by name only.
 * Android shares a device battery level only for some devices; when it does not, the
 * level stays unknown (-1) and the island simply does not show it.
 */
class BluetoothMonitor(
    private val context: Context,
    private val listener: Listener
) {

    data class DeviceInfo(
        val name: String?,
        val address: String,
        val isAudio: Boolean,
        val isAirPods: Boolean,
        val battery: Int
    )

    interface Listener {
        fun onDeviceConnected(device: DeviceInfo)
        fun onDeviceDisconnected(device: DeviceInfo)
        fun onBatteryLevel(address: String, level: Int)
    }

    companion object {
        /** Not part of the public SDK constants, but sent by Android since version 8.1. */
        const val ACTION_BATTERY_LEVEL_CHANGED = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY_LEVEL = "android.bluetooth.device.extra.BATTERY_LEVEL"
        private const val DEDUPE_MS = 3000L
    }

    private var registered = false
    private val lastEventTime = HashMap<String, Long>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val device = IntentCompat.getParcelableExtra(
                intent, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java
            ) ?: return
            when (intent.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    if (isDuplicate("c" + device.address)) return
                    listener.onDeviceConnected(describe(device))
                }
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    if (isDuplicate("d" + device.address)) return
                    listener.onDeviceDisconnected(describe(device))
                }
                ACTION_BATTERY_LEVEL_CHANGED -> {
                    val level = intent.getIntExtra(EXTRA_BATTERY_LEVEL, -1)
                    if (level in 0..100) listener.onBatteryLevel(device.address, level)
                }
            }
        }
    }

    fun start() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(ACTION_BATTERY_LEVEL_CHANGED)
        }
        // These broadcasts come from the system Bluetooth app, so the receiver must be exported.
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        registered = true
    }

    fun stop() {
        if (!registered) return
        try {
            context.unregisterReceiver(receiver)
        } catch (ignored: IllegalArgumentException) {
            // Already unregistered.
        }
        registered = false
    }

    private fun isDuplicate(key: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        val last = lastEventTime[key]
        lastEventTime[key] = now
        return last != null && now - last < DEDUPE_MS
    }

    @SuppressLint("MissingPermission")
    private fun describe(device: BluetoothDevice): DeviceInfo {
        val canRead = PermissionHelper.hasBluetoothPermission(context)
        val name: String? = if (canRead) {
            try {
                device.name
            } catch (ignored: SecurityException) {
                null
            }
        } else {
            null
        }
        val major: Int? = if (canRead) {
            try {
                device.bluetoothClass?.majorDeviceClass
            } catch (ignored: SecurityException) {
                null
            }
        } else {
            null
        }
        val isAirPods = name?.contains("airpods", ignoreCase = true) == true
        val isAudio = isAirPods || major == BluetoothClass.Device.Major.AUDIO_VIDEO ||
            (name?.let { looksLikeAudio(it) } == true)
        return DeviceInfo(name, device.address, isAudio, isAirPods, readBattery(device))
    }

    private fun looksLikeAudio(name: String): Boolean {
        val n = name.lowercase()
        return listOf("buds", "pods", "headphone", "headset", "earphone", "speaker", "audio", "sound")
            .any { n.contains(it) }
    }

    /**
     * Tries the hidden BluetoothDevice.getBatteryLevel() method. It is not a public API, so it
     * may be unavailable; in that case the battery level is reported as unknown (-1).
     */
    private fun readBattery(device: BluetoothDevice): Int = try {
        val value = device.javaClass.getMethod("getBatteryLevel").invoke(device) as? Int ?: -1
        if (value in 0..100) value else -1
    } catch (ignored: Throwable) {
        -1
    }
}
