package com.cuteisland.dynamicisland.ui

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.AnimationStyle
import com.cuteisland.dynamicisland.model.CharacterType
import com.cuteisland.dynamicisland.model.EventFactory
import com.cuteisland.dynamicisland.util.PermissionHelper
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Bluetooth and AirPods animation settings. */
class BluetoothSettingsActivity : BaseActivity() {

    private lateinit var island: IslandView
    private lateinit var permissionStatus: TextView
    private lateinit var allowButton: View

    private val bluetoothPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !shouldShowRequestPermissionRationale(Manifest.permission.BLUETOOTH_CONNECT)
        ) {
            showDeniedDialog()
        }
        refreshPermission()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth_settings)
        setupToolbar(R.string.bluetooth_title)

        island = findViewById(R.id.bt_island)
        setupPreview(island, sample(EventFactory.Sample.AIRPODS))

        permissionStatus = findViewById(R.id.bt_permission_status)
        allowButton = findViewById(R.id.btn_allow_bt)
        allowButton.setOnClickListener { askBluetoothPermission() }

        val switches = findViewById<LinearLayout>(R.id.switch_container)
        addSwitchRow(switches, R.string.sw_bt, R.string.sw_bt_desc, settings.bluetoothEnabled) {
            settings.bluetoothEnabled = it
        }
        addSwitchRow(switches, R.string.sw_bt_disconnect, R.string.sw_bt_disconnect_desc, settings.btDisconnectEnabled) {
            settings.btDisconnectEnabled = it
        }
        addSwitchRow(switches, R.string.sw_all_devices, R.string.sw_all_devices_desc, settings.btAllDevices) {
            settings.btAllDevices = it
        }
        addSwitchRow(switches, R.string.sw_bt_battery, R.string.sw_bt_battery_desc, settings.btShowBattery) {
            settings.btShowBattery = it
            replayPreview()
        }

        bindChips(
            findViewById<ChipGroup>(R.id.chips_style), AnimationStyle.entries,
            { getString(it.titleRes) }, settings.btStyle
        ) {
            settings.btStyle = it
            replayPreview()
        }
        bindChips(
            findViewById<ChipGroup>(R.id.chips_character), CharacterType.entries,
            { getString(it.nameRes) }, settings.btCharacter
        ) {
            settings.btCharacter = it
            replayPreview()
        }

        findViewById<View>(R.id.btn_test_airpods).setOnClickListener {
            playOnScreen(sample(EventFactory.Sample.AIRPODS), island)
        }
        findViewById<View>(R.id.btn_test_device).setOnClickListener {
            playOnScreen(sample(EventFactory.Sample.DEVICE), island)
        }
        findViewById<View>(R.id.btn_test_disconnect).setOnClickListener {
            playOnScreen(sample(EventFactory.Sample.DISCONNECTED), island)
        }
    }

    override fun onResume() {
        super.onResume()
        island.look = settings.look()
        refreshPermission()
    }

    private fun sample(s: EventFactory.Sample) = EventFactory.sample(this, settings, s)

    private fun replayPreview() {
        island.look = settings.look()
        island.event = sample(EventFactory.Sample.AIRPODS)
        island.play()
    }

    private fun refreshPermission() {
        val granted = PermissionHelper.hasBluetoothPermission(this)
        permissionStatus.setText(if (granted) R.string.bt_permission_granted else R.string.bt_permission_missing)
        permissionStatus.setTextColor(getColor(if (granted) R.color.accent_green else R.color.accent_amber))
        allowButton.visibility = if (granted) View.GONE else View.VISIBLE
    }

    private fun askBluetoothPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.permission_rationale_title)
            .setMessage(R.string.bt_rationale)
            .setPositiveButton(R.string.allow) { _, _ ->
                bluetoothPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
            }
            .setNegativeButton(R.string.not_now, null)
            .show()
    }

    private fun showDeniedDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.permission_rationale_title)
            .setMessage(R.string.permission_denied_body)
            .setPositiveButton(R.string.open_settings) { _, _ ->
                startActivity(PermissionHelper.appDetailsIntent(this))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
