package com.cuteisland.dynamicisland.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.cuteisland.dynamicisland.R
import com.cuteisland.dynamicisland.island.IslandView
import com.cuteisland.dynamicisland.model.AnimationStyle
import com.cuteisland.dynamicisland.model.EventFactory
import com.cuteisland.dynamicisland.model.IslandEvent

/** Shows every animation style with a live preview. */
class GalleryActivity : BaseActivity() {

    private class Row(val style: AnimationStyle, val island: IslandView, val inUse: TextView)

    private val rows = ArrayList<Row>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        setupToolbar(R.string.nav_gallery)
        findViewById<TextView>(R.id.intro_text).setText(R.string.gallery_intro)
        val container = findViewById<LinearLayout>(R.id.container)

        AnimationStyle.entries.forEach { style ->
            val card = layoutInflater.inflate(R.layout.item_animation_style, container, false)
            card.findViewById<TextView>(R.id.style_title).setText(style.titleRes)
            card.findViewById<TextView>(R.id.style_desc).setText(style.descRes)
            val island = card.findViewById<IslandView>(R.id.style_island)
            setupPreview(island, sampleFor(style))
            val inUse = card.findViewById<TextView>(R.id.style_in_use)
            card.findViewById<View>(R.id.btn_use_charging).setOnClickListener {
                settings.chargingStyle = style
                refreshInUse()
            }
            card.findViewById<View>(R.id.btn_use_bluetooth).setOnClickListener {
                settings.btStyle = style
                refreshInUse()
            }
            card.findViewById<View>(R.id.btn_test).setOnClickListener {
                playOnScreen(sampleFor(style), island)
            }
            rows.add(Row(style, island, inUse))
            container.addView(card)
        }
    }

    override fun onResume() {
        super.onResume()
        val look = settings.look()
        rows.forEach {
            it.island.look = look
            it.island.event = sampleFor(it.style)
        }
        refreshInUse()
    }

    private fun sampleFor(style: AnimationStyle): IslandEvent {
        val sample = if (style == AnimationStyle.BLUETOOTH) EventFactory.Sample.AIRPODS else EventFactory.Sample.CHARGING
        val base = EventFactory.sample(this, settings, sample)
        return base.copy(style = style)
    }

    private fun refreshInUse() {
        val charging = settings.chargingStyle
        val bt = settings.btStyle
        rows.forEach { row ->
            val text = when {
                row.style == charging && row.style == bt -> R.string.in_use_both
                row.style == charging -> R.string.in_use_charging
                row.style == bt -> R.string.in_use_bluetooth
                else -> R.string.in_use_none
            }
            row.inUse.setText(text)
            row.inUse.setTextColor(getColor(if (text == R.string.in_use_none) R.color.text_muted else R.color.accent_green))
        }
    }
}
