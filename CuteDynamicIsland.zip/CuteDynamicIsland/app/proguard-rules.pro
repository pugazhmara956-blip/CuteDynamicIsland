# Minification is turned off by default. These rules are kept for when you enable it.
-keep class com.cuteisland.dynamicisland.** { *; }
