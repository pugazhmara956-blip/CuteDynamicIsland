# Cute Dynamic Island – Battery & Bluetooth Animations

A native Android app (Kotlin) that shows a cute, animated, Dynamic Island-style pill at the top of your screen when you plug in your charger, unplug it, reach 100%, or connect and disconnect Bluetooth devices such as AirPods. It was written with the Redmi 14C 5G (HyperOS / Android 14) in mind.

Everything is free. There are no ads, no purchases, no subscriptions, no internet permission and no accounts. All characters are original artwork drawn by the app in code, so no image files or downloads are needed.

---

## 1. Project architecture

```
CuteDynamicIsland/
├── build.gradle.kts              Top-level Gradle plugins
├── settings.gradle.kts           Project name and repositories
├── gradle.properties             Gradle options
├── gradlew, gradlew.bat          Gradle wrapper scripts
├── gradle/wrapper/               Wrapper JAR and properties (Gradle 8.9)
└── app/
    ├── build.gradle.kts          App settings and dependencies
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml   Permissions, screens, service, boot receiver
        ├── java/com/cuteisland/dynamicisland/
        │   ├── model/
        │   │   ├── Models.kt           Styles, characters, events, look settings
        │   │   └── EventFactory.kt     Builds English island messages
        │   ├── data/
        │   │   └── IslandSettings.kt   Saves settings locally (SharedPreferences)
        │   ├── island/
        │   │   ├── IslandView.kt       The animated pill (open, expand, hold, close)
        │   │   ├── IslandEffects.kt    Battery, sparks, Bluetooth waves, ring, sizes
        │   │   ├── CharacterRenderer.kt All 11 original characters, drawn in code
        │   │   └── CharacterView.kt    Character preview widget
        │   ├── overlay/
        │   │   └── IslandOverlay.kt    WindowManager overlay window
        │   ├── service/
        │   │   ├── IslandService.kt    Foreground service (no polling)
        │   │   ├── BatteryMonitor.kt   Charger and 100% detection
        │   │   └── BluetoothMonitor.kt Bluetooth and AirPods detection
        │   ├── receiver/
        │   │   └── BootReceiver.kt     Restarts the service after a reboot
        │   ├── util/
        │   │   └── PermissionHelper.kt Permission checks and Xiaomi settings pages
        │   └── ui/
        │       ├── BaseActivity.kt     Shared helpers (switches, sliders, chips, tests)
        │       ├── MainActivity.kt     Home screen
        │       ├── GalleryActivity.kt  Animation gallery
        │       ├── CharactersActivity.kt Character collection
        │       ├── BatterySettingsActivity.kt
        │       ├── BluetoothSettingsActivity.kt
        │       ├── AppearanceActivity.kt Theme and island customization
        │       ├── PreviewActivity.kt  Preview screen
        │       ├── SetupActivity.kt    Permissions and Xiaomi setup
        │       └── HelpActivity.kt     Help and limitations
        └── res/
            ├── layout/   18 XML layouts
            ├── values/   strings.xml (English only), colors.xml, themes.xml
            ├── drawable/ Original vector icons and backgrounds
            └── mipmap-anydpi-v26/ Adaptive launcher icon
```

### How the pieces work together

1. `IslandService` runs as a small foreground service. It registers two receivers and then waits; it does not poll, so battery use is very low.
2. `BatteryMonitor` listens to `ACTION_POWER_CONNECTED`, `ACTION_POWER_DISCONNECTED` and `ACTION_BATTERY_CHANGED` (BatteryManager data). It announces 100% only once per charging session.
3. `BluetoothMonitor` listens to `ACTION_ACL_CONNECTED`, `ACTION_ACL_DISCONNECTED` and the system battery-level broadcast. AirPods are recognised by name and treated as normal Bluetooth headphones.
4. `EventFactory` turns each event into an `IslandEvent` with English text and your chosen style and character.
5. `IslandOverlay` adds an `IslandView` to the screen with `WindowManager` (`TYPE_APPLICATION_OVERLAY`). The window is only as large as the island and is removed as soon as the animation ends. Tap the island to close it early.
6. `BootReceiver` starts the service again after a reboot (Xiaomi Autostart must be on).

## 2. Technologies used

| Item | Version |
|---|---|
| Language | Kotlin 2.0.21 |
| Build system | Gradle 8.9, Android Gradle Plugin 8.7.3 |
| UI | XML layouts, Material Components 1.12.0 (Material 3 dark theme) |
| Libraries | androidx.core 1.13.1, androidx.appcompat 1.7.0 |
| Min / target Android | Android 8.0 (API 26) / Android 15 (API 35) |
| Android APIs | BatteryManager, Bluetooth broadcasts, BroadcastReceiver, WindowManager overlay, foreground service, SharedPreferences |

**About Lottie:** the prompt allowed Lottie "where appropriate". The app does not use it. Every animation is drawn in code with Canvas instead, because that keeps all artwork original, keeps the app tiny, avoids external animation files whose licences would need checking, and lets every animation follow your speed, size and color settings.

## 3. Implemented features

**Charging:** charger connected (battery percentage, charger type: USB, AC charger or wireless), charger disconnected, fully charged at 100% (once per session). Each can be turned on or off.

**Bluetooth and AirPods:** device connected and disconnected, device name, a special "AirPods Connected" title and pink accent when the name contains "AirPods", a battery level only when Android shares it, an option for all devices or only audio devices, and a disconnection animation.

**Seven animation styles:** Small Pill, Expanding Island, Bouncing Character, Charging Electricity, Glowing Battery, Bluetooth Connection and Walking Character. All styles include smooth opening and closing transitions.

**Eleven original characters:** Mittens and Pip (an original cat-and-mouse pair), Biscuit the Kitten, Buddy the Puppy, Bamboo the Panda, Cocoa the Teddy Bear, Hopper the Bunny, Skye the Anime Star, Lovely Hearts, Sparky the Battery, Wobbles the Blob and Earbud Buddy. They blink, bounce, wave and walk, and each has happy, excited and sad expressions.

**Customization:** width, height, corner radius, distance from top, left, center or right alignment, seven background colors, animation speed (0.5x to 2.0x), display time (2 to 10 seconds), separate style and character for charging and for Bluetooth, a main on/off switch, and individual on/off switches.

**Screens:** Home (live preview, on/off switch, quick tests), Animation Gallery, Character Collection, Battery Animations, Bluetooth and AirPods, Island Appearance (theme settings), Preview Screen, Permissions and Setup, and Help and Tips.

**Other:** test buttons on every settings screen, settings saved on the phone, works offline, restarts after reboot, English-only interface (the build also strips other languages from the libraries).

## 4. Permissions and why they are needed

| Permission | Why |
|---|---|
| Display over other apps | Required to draw the island on top of other apps. |
| Bluetooth (Nearby devices) | Required on Android 12+ to be told when a device connects and to read its name. The app never scans or pairs. |
| Notifications | Android requires a notification for a background service. It uses the lowest priority. |
| Foreground service (special use) | Keeps the event listener alive in the background. |
| Run at startup | Restarts the service after a reboot. |
| Ignore battery optimizations | Lets the app show the system dialog that stops Android from closing the service. |

No internet, location, storage, camera, microphone or contacts permissions are used.

---

## 5. Step-by-step guide for beginners

### Step 1: Install Android Studio and open the project
1. Download and install the latest stable **Android Studio** from developer.android.com/studio. Accept the default options; it installs the Android SDK for you.
2. Unzip `CuteDynamicIsland.zip` to a simple folder, for example `C:\Projects\CuteDynamicIsland` or `~/Projects/CuteDynamicIsland`.
3. Open Android Studio and choose **Open** (not "New Project"). Select the `CuteDynamicIsland` folder that contains `settings.gradle.kts`.
4. Wait for **Gradle Sync** to finish (bottom status bar). The first sync downloads Gradle and libraries and needs an internet connection. It can take several minutes.
5. If Android Studio offers to upgrade the Android Gradle Plugin, you can accept. If it says an SDK platform is missing, click the suggested **Install** link.

### Step 2: How the files are organised
You do not need to create any files by hand: the zip already contains the complete project. If you ever want to create the project manually instead, create an "Empty Views Activity" project with the package name `com.cuteisland.dynamicisland`, Kotlin, and minimum SDK API 26, then replace its `app/src/main` folder and Gradle files with the ones from this zip, keeping the same folder structure shown above.

### Step 3: Build the APK
1. In Android Studio, open the **Build** menu.
2. Choose **Build App Bundle(s) / APK(s) → Build APK(s)**. In newer versions this is called **Generate App Bundles or APKs → Generate APKs**.
3. When it finishes, click **locate** in the pop-up. The file is `app/build/outputs/apk/debug/app-debug.apk`.

Command line alternative (with the Android SDK installed): run `./gradlew assembleDebug` on macOS or Linux, or `gradlew.bat assembleDebug` on Windows, from the project folder.

### Step 4: Install the APK on your Redmi 14C 5G
**Option A: Copy the file (easiest)**
1. Copy `app-debug.apk` to the phone (USB cable, Google Drive, or Bluetooth).
2. Open **Files** on the phone and tap the APK.
3. When asked, allow your file manager to **Install unknown apps**, then tap **Install**. If Xiaomi shows a security scan, wait for it and tap **Install anyway** (the app is your own build).

**Option B: Install directly from Android Studio**
1. On the phone, open **Settings → About phone** and tap **OS version** seven times to unlock Developer options.
2. Open **Settings → Additional settings → Developer options**. Turn on **USB debugging** and **Install via USB** (Xiaomi may ask you to sign in to a Xiaomi account and insert a SIM card for this).
3. Connect the phone with a USB cable and accept the "Allow USB debugging" prompt.
4. In Android Studio, select your phone at the top and press the green **Run** button.

### Step 5: Enable Display over other apps
1. Open the app. Tap **Finish Setup** on the home screen, or open **Permissions & Setup**.
2. Tap **Allow** next to **Display over other apps**.
3. Find **Cute Dynamic Island** in the list and turn the switch on. Press Back.
4. Manual path if needed: **Settings → Apps → Manage apps → Cute Dynamic Island → Other permissions → Display pop-up windows** (wording varies between HyperOS versions).

### Step 6: Enable Bluetooth permission
1. In **Permissions & Setup**, tap **Allow** next to **Bluetooth access**, read the explanation and tap **Allow**.
2. In the Android dialog, choose **Allow** for "Nearby devices".
3. If you denied it earlier: **Settings → Apps → Manage apps → Cute Dynamic Island → App permissions → Nearby devices → Allow**.

### Step 7: Allow background operation on Xiaomi
HyperOS closes background apps aggressively. Do all of these:
1. **Notifications:** allow them in Permissions & Setup.
2. **Battery:** tap **Allow** next to **Unrestricted battery usage**. Also check **Settings → Apps → Manage apps → Cute Dynamic Island → Battery saver → No restrictions**.
3. **Autostart:** tap **Open** next to **Xiaomi Autostart** and turn on Cute Dynamic Island.
4. **Pop-up windows:** tap **Open** next to **Xiaomi pop-up windows** and allow **Display pop-up windows while running in the background**.
5. **Lock in Recents:** open the Recents screen, long-press the app card and tap the lock icon.
6. Back on the home screen, make sure **Show animations** is on and the status says **Running**.

### Step 8: Test charging and AirPods animations
1. **Without hardware:** use the **Quick test** buttons on the home screen, the **Test** buttons on the settings screens, or the **Preview Screen**.
2. **Charging:** go to your home screen or any app, then plug in the charger. The charging island appears. Unplug to see the unplugged island. The fully charged island appears once when the battery reaches 100% while plugged in.
3. **AirPods:** pair your AirPods once in **Settings → Bluetooth** (hold the button on the case until the light flashes white). After that, open the case near the phone; the island appears when Android connects to them. Close the case to see the disconnection animation.
4. **Other Bluetooth devices:** turn on any paired headphones or speaker. Turn off **Show for all Bluetooth devices** if smartwatches or cars show the island too often.

---

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| Gradle sync fails | Check your internet connection, then **File → Sync Project with Gradle Files**. Accept any suggested SDK or plugin installs. Make sure the Gradle JDK is 17 or newer (**Settings → Build, Execution, Deployment → Build Tools → Gradle**). |
| "SDK location not found" | Open the project in Android Studio once; it creates `local.properties` with your SDK path automatically. |
| Test shows inside the app but not on top | Display over other apps is not allowed yet. See Step 5. |
| Nothing happens when charging | Check that **Show animations** is on and the status says **Running**. Then redo Step 7. Check that the charging switches are on in Battery Animations. |
| Works for a while, then stops | Xiaomi closed the service. Redo Step 7, especially Battery saver (No restrictions) and Autostart, and lock the app in Recents. |
| No Bluetooth island | Allow Bluetooth access (Step 6). On Android 12+ the app receives no Bluetooth events without it. |
| AirPods battery level missing | This is normal. Android usually does not share AirPods battery levels with apps. |
| Status bar icons show on top of the island | Android draws app overlays below the status bar. Increase **Distance from top** in Island Appearance. |
| Island not visible on the lock screen | Android does not allow normal app overlays on the lock screen. |

## 7. Testing results (honest status)

The workspace used to write this project has no Android SDK, no Kotlin compiler and no internet access, so **the project has not been compiled, installed or run yet.** The following checks were run there:

- All 44 XML files (resources and manifest) parsed successfully (well-formed XML).
- An automated check confirmed that every `R.string`, `R.id`, `R.layout`, `R.drawable` and `R.color` reference in the Kotlin code exists, that every `@string`, `@color`, `@drawable`, `@layout` and `@style` reference in the XML exists, that every view ID used by each screen exists in that screen's layouts, that all imports of the app's own classes exist, that brackets are balanced in every Kotlin file, and that every vector icon path uses valid syntax.
- An automated check confirmed that all 226 strings are English, ASCII text apart from normal English punctuation (–, •, ·), with no unescaped apostrophes.
- The Gradle wrapper was generated with a real Gradle installation.

Please run the first build in Android Studio. If the build shows any error, copy the full message and it can be fixed quickly.

## 8. Known limitations

- The island cannot appear on the lock screen, over secure screens (some banking or payment apps, password fields that block overlays) or over some system screens.
- App overlays are drawn below the status bar, so status bar icons may appear over the island near the camera. Move it lower if this bothers you. Drawing above the status bar would need an Accessibility Service, which this app deliberately does not use.
- AirPods battery levels are normally not available on Android. AirPods are detected by their Bluetooth name, so renamed AirPods show as a normal device.
- Exact charging power (watts) is not available through public Android APIs, so the charger type is shown instead.
- Xiaomi system settings can still stop background apps despite all precautions.
- Some broadcasts can arrive twice on some phones; duplicates within three seconds are ignored.

## 9. Deployment

- **For your own phone:** the debug APK from Step 3 is all you need.
- **Signed release APK:** in Android Studio choose **Build → Generate Signed App Bundle / APK → APK**, create a new keystore (keep the file and passwords safe and never share or commit them), choose **release**, and finish. The APK is in `app/release/`.
- **Google Play:** Google Play reviews apps that use the "special use" foreground service type and the overlay permission. You would need to explain the use case in the Play Console. This project has not been submitted anywhere.

## 10. Final project status

The source code is complete for every requested feature, screen and setting, with no placeholders, mock services or locked content. It still needs its first real build and device test in Android Studio, as explained in section 7.
